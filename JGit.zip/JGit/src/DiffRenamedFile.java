import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.diff.DiffConfig;
import org.eclipse.jgit.diff.DiffEntry;
import org.eclipse.jgit.diff.DiffFormatter;
import org.eclipse.jgit.diff.RenameDetector;
import org.eclipse.jgit.errors.IncorrectObjectTypeException;
import org.eclipse.jgit.errors.MissingObjectException;
import org.eclipse.jgit.lib.*;
import org.eclipse.jgit.revwalk.*;
import org.eclipse.jgit.storage.file.FileRepositoryBuilder;
import org.eclipse.jgit.treewalk.AbstractTreeIterator;
import org.eclipse.jgit.treewalk.CanonicalTreeParser;
import org.eclipse.jgit.treewalk.FileTreeIterator;
import org.eclipse.jgit.treewalk.TreeWalk;

// Simple example that shows how to diff a single file between two commits when
// the file may have been renamed.
public class DiffRenamedFile {
    private static AbstractTreeIterator prepareTreeParser(Repository repository, String objectId) throws IOException,
            MissingObjectException,
            IncorrectObjectTypeException {
        // from the commit we can build the tree which allows us to construct the TreeParser
        RevWalk walk = new RevWalk(repository);
        RevCommit commit = walk.parseCommit(ObjectId.fromString(objectId));
        RevTree tree = walk.parseTree(commit.getTree().getId());

        CanonicalTreeParser oldTreeParser = new CanonicalTreeParser();
        ObjectReader oldReader = repository.newObjectReader();
            oldTreeParser.reset(oldReader, tree.getId());


        walk.dispose();

        return oldTreeParser;
    }

    private static DiffEntry diffFile(Repository repo, String oldCommit,
                                      String newCommit, String path) throws IOException, GitAPIException {
        Config config = new Config();
        config.setBoolean("diff", null, "renames", true);
        DiffConfig diffConfig = config.get(DiffConfig.KEY);
        List<DiffEntry> diffList = new Git(repo).diff().
                setOldTree(prepareTreeParser(repo, oldCommit)).
                setNewTree(prepareTreeParser(repo, newCommit)).
                setPathFilter(FollowFilter.create(path, diffConfig)).
                call();
        if (diffList.size() == 0)
            return null;
        if (diffList.size() > 1)
            throw new RuntimeException("invalid diff");
        return diffList.get(0);
    }

    public static void main(String args[])
            throws IOException, GitAPIException {
        FileRepositoryBuilder builder = new FileRepositoryBuilder();
        Repository repository = builder.setGitDir(new File("C:/Users/Elyes/Desktop/Hexel/Hexel/.git"))
                .readEnvironment() // scan environment GIT_* variables
                .findGitDir() // scan up the file system tree
                .build();

       /*  TreeWalk tw = new TreeWalk(repository);
        tw.setRecursive(true);

        RevWalk walk = new RevWalk(repository);
        ObjectId id = repository.resolve("eb8b87b6120d2be554eb135ec6e34a2023b61550");
        RevCommit commit = walk.parseCommit(id);

        System.out.println("message of commit "+commit.getShortMessage());
        tw.addTree(commit.getTree());
        tw.addTree(new FileTreeIterator(repository));
        RenameDetector rd = new RenameDetector(repository);
        rd.addAll(DiffEntry.scan(tw));

        List<DiffEntry> lde = rd.compute();
        for (DiffEntry de : lde) {
            System.out.println(de.getNewPath());
            if (de.getScore() >= rd.getRenameScore()) {
                System.out.println("file: " + de.getOldPath() + " copied/moved to: " + de.getNewPath());
            }
        }

       TreeWalk tw = new TreeWalk(repository);
        tw.setRecursive(true);
        tw.addTree(CommitUtils.getHead(repository).getTree());
        tw.addTree(new FileTreeIterator(repository));

        RenameDetector rd = new RenameDetector(repository);
        rd.addAll(DiffEntry.scan(tw));

        List<DiffEntry> lde = rd.compute(tw.getObjectReader(), null);
        for (DiffEntry de : lde) {
            if (de.getScore() >= rd.getRenameScore()) {
                System.out.println("file: " + de.getOldPath() + " copied/moved to: " + de.getNewPath());
            }
        }*/

        /*RevWalk walk = new RevWalk(repository);

        AnyObjectId  headId = repository.resolve(Constants.HEAD);
        RevCommit root = walk.parseCommit(headId);
        walk.sort(RevSort.REVERSE);
        walk.markStart(root);

        String oldHash = walk.next().getName();
        System.out.println(oldHash);
        AbstractTreeIterator oldTreeParser;
        AbstractTreeIterator newTreeParser;
        for (RevCommit rev : walk){

            oldTreeParser = prepareTreeParser(repository, oldHash);
            newTreeParser = prepareTreeParser(repository, rev.name());
            List<DiffEntry> diffs= new Git(repository).diff()
                    .setNewTree(newTreeParser)
                    .setOldTree(oldTreeParser)
                    .call();
            //System.out.println("-------------" + rev.getShortMessage()+"-------------");
            for (DiffEntry entry : diffs) {
                if(entry.getNewPath().contains(".java") || entry.getOldPath().contains(".java")) {
                    //System.out.println("old "+entry.getOldPath());
                    //System.out.println("new "+entry.getNewPath());
                }
                if(entry.getNewPath().contains(".java") && !entry.getOldPath().equals("/dev/null") )
                {
                    DiffEntry diff = diffFile(repository, oldHash, rev.name(), entry.getNewPath());
                    DiffFormatter formatter = new DiffFormatter(System.out);
                    formatter.setRepository(repository);
                    //formatter.format(diff);

                    if(diff.getChangeType().equals("RENAME")){
                       System.out.println(formatter.toFileHeader(diff));
                    }


                }
            }
            oldHash = rev.getId().getName();
        }

        // Diff README.md between two commits. The file is named README.md in
        // the new commit (5a10bd6e), but was named "jgit-cookbook README.md" in
        // the old commit (2e1d65e4).



      /* DiffEntry diff = diffFile(repository,
                "377613401312c9fbe6634c837cb8ee9126792900",
                "52e3f855900fc0c72751f42524617ffbc133801c",
                "src/main/java/Hexel/blocks/LeafBlock.java");
        //90b94fd2c651939d63ec6f0eafe8b6de2a3b525b
        // Display the diff.
        DiffFormatter formatter = new DiffFormatter(System.out);
        formatter.setRepository(repository);
        //formatter.format(diff);
        System.out.println(diff);
        if(diff != null) {
            System.out.println(diff.getChangeType());
            System.out.println(formatter.toFileHeader(diff));
        }*/

        RevWalk walk = new RevWalk(repository);
        AnyObjectId  headId = repository.resolve(Constants.HEAD);
        RevCommit root = walk.parseCommit(headId);
        walk.sort(RevSort.REVERSE);
        walk.markStart(root);
        RevCommit firstRev = walk.next();
        String oldHash = firstRev.getName();
        AbstractTreeIterator oldTreeParser;
        AbstractTreeIterator newTreeParser;
        ArrayList<String> listCommitsKey = new ArrayList<String>();
        listCommitsKey.add(oldHash);

        for (RevCommit commit : walk){

            oldTreeParser = prepareTreeParser(repository, oldHash);
            newTreeParser = prepareTreeParser(repository, commit.name());
            List<DiffEntry> diffs= new Git(repository).diff()
                    .setNewTree(newTreeParser)
                    .setOldTree(oldTreeParser)
                    .call();
            System.out.println(commit.getShortMessage());

            for (DiffEntry entry : diffs) {

                if (entry.getChangeType().toString().equals("ADD") && entry.getNewPath().contains(".java")) {

                    for(String key : listCommitsKey){

                        DiffEntry diff = diffFile(repository,key,commit.name(),entry.getNewPath());
                        DiffFormatter formatter = new DiffFormatter(System.out);
                        formatter.setRepository(repository);

                        if(diff != null && diff.getChangeType().toString().equals("RENAME")) {
                            //System.out.println(diff.getChangeType());
                            System.out.println(formatter.toFileHeader(diff));
                            break ;
                        }

                    }
                }

            }

            oldHash = commit.getId().getName();
            listCommitsKey.add(commit.name());
        }

    }

    public  void VerifRenames() throws IOException, GitAPIException {

        FileRepositoryBuilder builder = new FileRepositoryBuilder();
        Repository repository = builder.setGitDir(new File("C:/Users/Elyes/Desktop/Hexel/Hexel/.git"))
                .readEnvironment() // scan environment GIT_* variables
                .findGitDir() // scan up the file system tree
                .build();

        RevWalk walk = new RevWalk(repository);
        AnyObjectId  headId = repository.resolve(Constants.HEAD);
        RevCommit root = walk.parseCommit(headId);
        walk.sort(RevSort.REVERSE);
        walk.markStart(root);
        AbstractTreeIterator oldTreeParser;
        AbstractTreeIterator newTreeParser;
        ArrayList<String> listCommitsKey = new ArrayList<String>();
        String oldHash = walk.next().getName();
        listCommitsKey.add(oldHash);

        for (RevCommit commit : walk){

            oldTreeParser = prepareTreeParser(repository, oldHash);
            newTreeParser = prepareTreeParser(repository, commit.name());
            List<DiffEntry> diffs= new Git(repository).diff()
                    .setNewTree(newTreeParser)
                    .setOldTree(oldTreeParser)
                    .call();

            for (DiffEntry entry : diffs) {

                if(entry.getNewPath().contains(".java") ){
                    System.out.println(commit.getShortMessage());
                    System.out.println(entry);
                }
            }


            listCommitsKey.add(commit.name());
        }


    }
}