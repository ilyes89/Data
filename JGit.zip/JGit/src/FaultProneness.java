/**
 * Created by Elyes on 05/10/2015.
 */
import com.gitblit.utils.DiffStatFormatter;
import com.sun.org.apache.xpath.internal.SourceTree;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.diff.DiffEntry;
import org.eclipse.jgit.diff.DiffFormatter;
import org.eclipse.jgit.diff.RawTextComparator;
import org.eclipse.jgit.errors.IncorrectObjectTypeException;
import org.eclipse.jgit.errors.MissingObjectException;
import org.eclipse.jgit.lib.*;
import org.eclipse.jgit.revwalk.RevCommit;
import org.eclipse.jgit.revwalk.RevSort;
import org.eclipse.jgit.revwalk.RevTree;
import org.eclipse.jgit.revwalk.RevWalk;
import org.eclipse.jgit.storage.file.FileRepositoryBuilder;
import org.eclipse.jgit.treewalk.AbstractTreeIterator;
import org.eclipse.jgit.treewalk.CanonicalTreeParser;
import java.io.*;
import java.util.List;
import java.util.regex.*;

public class FaultProneness {


    private static AbstractTreeIterator prepareTreeParser(Repository repository, String objectId) throws IOException,
            MissingObjectException,
            IncorrectObjectTypeException {
        // from the commit we can build the tree which allows us to construct the TreeParser
        RevWalk walk = new RevWalk(repository);
        RevCommit commit = walk.parseCommit(ObjectId.fromString(objectId));
        RevTree tree = walk.parseTree(commit.getTree().getId());

        CanonicalTreeParser oldTreeParser = new CanonicalTreeParser();
        ObjectReader oldReader = repository.newObjectReader();
        oldTreeParser.reset(oldReader, tree.getId());


        walk.dispose();

        return oldTreeParser;
    }


    public static boolean isCommitBugFix (String commitMessage){

       // Pattern pattern = Pattern.compile("(?=.*(fix|close|correct))|(?=.*(bug|defect|error|problem|issue))");
        Pattern pattern = Pattern.compile("(?=.*(fix|close|correct))");
        Pattern pattern1 = Pattern.compile("(?=.*(bug|defect|patch|error|problem|issue))");
        Pattern pattern2 = Pattern.compile("(?=.*[0-9]+)");
        String message = commitMessage.toLowerCase();

        if(pattern.matcher(message).find() && pattern1.matcher(message).find() || pattern.matcher(message).find() && pattern2.matcher(message).find()
                || pattern1.matcher(message).find() && pattern2.matcher(message).find())
            return true;
        else
            return false ;
    }


    public static void prepareFile(FileWriter file,Repository repository) throws IOException {

        RevWalk walk = new RevWalk(repository);
        AnyObjectId  headId = repository.resolve(Constants.HEAD);
        RevCommit root = walk.parseCommit(headId);
        walk.sort(RevSort.REVERSE);
        walk.markStart(root);

        file.write("Revisions,");
        int nbRev = 0 ;
        int diff=1;
        for(RevCommit rev : walk){
            nbRev++;

            if(diff>2717)
           {
                if(rev.getParentCount()>0 && isCommitBugFix(rev.getShortMessage())) {

                    //System.out.println(rev.getFullMessage()+"\n");
                    file.append(rev.getShortMessage().replaceAll("[,]", " ") + ",");
                    if (nbRev > 3799) //specify commit number to extract
                    {

                        break;
                    }
                 }
            }
            diff++;
        }
        file.append("Total\n");

    }
    public static void main (String...arg) throws IOException, GitAPIException {

        FileRepositoryBuilder builder = new FileRepositoryBuilder();
        Repository repository = builder.setGitDir(new File("C:/Users/Elyes/Desktop/Data_projects/rhino/1.7_R4/rhino/.git"))
                .readEnvironment() // scan environment GIT_* variables
                .findGitDir() // scan up the file system tree
                .build();

        RevWalk walk = new RevWalk(repository);
        AnyObjectId  headId = repository.resolve(Constants.HEAD);
        RevCommit root = walk.parseCommit(headId);
        walk.sort(RevSort.REVERSE);
        walk.markStart(root);

        final File folder = new File("C:/Users/Elyes/stabilityPoint/rhino/1.7_R4/data");
        for (final File fileEntry : folder.listFiles()) {

            FileWriter file = new FileWriter("C:/Users/Elyes/stabilityPoint/rhino/1.7_R4/data/"+fileEntry.getName().substring(0,fileEntry.getName().length()-4)+".csv", true);
            prepareFile(file, repository);


            FileReader fileReader = new FileReader("C:/Users/Elyes/stabilityPoint/rhino/1.7_R4/data/"+fileEntry.getName());
            BufferedReader br = new BufferedReader(fileReader);
            String line, className;

            while ((line = br.readLine()) != null) {

                className = line.substring(line.indexOf(":") + 1, line.length() - 1);

                walk = new RevWalk(repository);
                headId = repository.resolve(Constants.HEAD);
                root = walk.parseCommit(headId);
                walk.sort(RevSort.REVERSE);
                walk.markStart(root);

                file.append(className + ",");
                int totalModification = 0;
                int nbRev = 0; //add only when to specify revisions number
                int diffe=1;
                boucle:
                for (RevCommit commit : walk) {

                    if(diffe>2717) {
                        boolean classIsModified = false;
                        nbRev++;
                        if (commit.getParentCount() > 0 && isCommitBugFix(commit.getShortMessage())) {
                            RevCommit parent = walk.parseCommit(commit.getParent(0).getId());
                            DiffStatFormatter df = new DiffStatFormatter(commit.getName());
                            df.setRepository(repository);
                            df.setDiffComparator(RawTextComparator.DEFAULT);
                            df.setDetectRenames(true);
                            List<DiffEntry> diffs = df.scan(parent.getTree(), commit.getTree());

                            for (DiffEntry diff : diffs) {

                                String ModifiedclassName = "/" + className.toLowerCase() + ".java";
                                //System.out.println(ModifiedclassName);
                                //System.out.println(diff.getNewPath().toLowerCase());
                                if (diff.getNewPath().toLowerCase().contains(ModifiedclassName)) {
                                    classIsModified = true;
                                    file.append(diff.getChangeType().toString() + ",");
                                    totalModification++;
                                    break;
                                }
                            }
                            if (!classIsModified) {
                                file.append(",");
                            }
                            if (nbRev > 3799) //specify last revision
                                break boucle;
                        }
                     }
                    diffe++;
                }
                file.append("" + totalModification + "\n");
            }

            fileReader.close();
            file.close();
        }
        repository.close();
    }


}