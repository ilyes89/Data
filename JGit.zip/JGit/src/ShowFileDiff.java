/**
 * Created by Elyes on 26/11/2015.
 */
        import java.io.File;
        import java.io.IOException;
        import java.util.List;


        import org.eclipse.jgit.api.Git;
        import org.eclipse.jgit.api.errors.GitAPIException;
        import org.eclipse.jgit.diff.DiffEntry;
        import org.eclipse.jgit.diff.DiffFormatter;
        import org.eclipse.jgit.errors.IncorrectObjectTypeException;
        import org.eclipse.jgit.errors.MissingObjectException;
        import org.eclipse.jgit.lib.ObjectId;
        import org.eclipse.jgit.lib.ObjectReader;
        import org.eclipse.jgit.lib.Repository;
        import org.eclipse.jgit.revwalk.RevCommit;
        import org.eclipse.jgit.revwalk.RevTree;
        import org.eclipse.jgit.revwalk.RevWalk;
        import org.eclipse.jgit.storage.file.FileRepositoryBuilder;
        import org.eclipse.jgit.treewalk.AbstractTreeIterator;
        import org.eclipse.jgit.treewalk.CanonicalTreeParser;
        import org.eclipse.jgit.treewalk.filter.PathFilter;



/**
 * Simple snippet which shows how to show diffs between branches
 *
 * @author dominik.stadler at gmx.at
 */
public class ShowFileDiff {

    public static void main(String[] args) throws IOException, GitAPIException {

        FileRepositoryBuilder builder = new FileRepositoryBuilder();
        Repository repository = builder.setGitDir(new File("C:/Users/Elyes/Desktop/Change_Proneness_Projects/Hexel/.git"))
                .readEnvironment() // scan environment GIT_* variables
                .findGitDir() // scan up the file system tree
                .build();

            // the diff works on TreeIterators, we prepare two for the two branches
            AbstractTreeIterator oldTreeParser = prepareTreeParser(repository, "84b72cfdedf5aff945deda52969405210e5170ca");
            AbstractTreeIterator newTreeParser = prepareTreeParser(repository, "2c99076efca3efbae4989ef9a3a5120c777aa7d1");

            // then the procelain diff-command returns a list of diff entries
            Git git = new Git(repository);
                List<DiffEntry> diff = git.diff().
                        setOldTree(oldTreeParser).
                        setNewTree(newTreeParser).
                        setPathFilter(PathFilter.create("src/main/java/Hexel/Hexel.java")).
                        call();
                for (DiffEntry entry : diff) {
                    System.out.println("Entry: " + entry + ", from: " + entry.getOldId() + ", to: " + entry.getNewId());
                    DiffFormatter formatter = new DiffFormatter(System.out);
                        formatter.setRepository(repository);
                        formatter.format(entry);

                }

        }


    private static AbstractTreeIterator prepareTreeParser(Repository repository, String objectId) throws IOException,
            MissingObjectException,
            IncorrectObjectTypeException {
        // from the commit we can build the tree which allows us to construct the TreeParser
        RevWalk walk = new RevWalk(repository);
            RevCommit commit = walk.parseCommit(ObjectId.fromString(objectId));
            RevTree tree = walk.parseTree(commit.getTree().getId());

            CanonicalTreeParser oldTreeParser = new CanonicalTreeParser();
            ObjectReader oldReader = repository.newObjectReader();
                oldTreeParser.reset(oldReader, tree.getId());


            walk.dispose();

            return oldTreeParser;

    }
}