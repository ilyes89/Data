import java.util.ArrayList;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Elyes on 30/03/2016.
 */
public class RegExTest {

    public static  void main (String...tab){

        Pattern pattern = Pattern.compile("(?=.*(fix|close|correct))");
        Pattern pattern1 = Pattern.compile("(?=.*(bug|defect|error|problem|issue))");
        Pattern pattern2 = Pattern.compile("(?=.*[0-9]+)");


//        ArrayList<Pattern> list = new ArrayList<Pattern>();
//        list.add(Pattern.compile("(?=.*(fix|close|correct))"));
//        list.add(Pattern.compile("(?=.*(bug|defect|error|problem|issue))"));
//        list.add(Pattern.compile("(?=.*[0-9]+)"));



        if(pattern.matcher(" fix bug 11").find() && pattern1.matcher("fix bug 11").find() || pattern.matcher("fix bug 11").find() && pattern2.matcher(" fix bug 11").find()
                || pattern1.matcher("fix bug 11").find() && pattern2.matcher(" fix bug 11").find())
        {
            System.out.println("true");
        }

    }
}
