package softvis.views;

import infoHidingVisu.app.Constants;
import infoHidingVisu.codehistory.CodeHistoryController;
import infoHidingVisu.interactor.PopupMenuInteractor;
import infoHidingVisu.interactor.RectangularShapeSelector;
import infoHidingVisu.shape.ClusterVisualShape;
import infoHidingVisu.shape.GWShapesEventHandler;
import infoHidingVisu.shape.VisualShapeAttributes;
import infoHidingVisu.ui.UserInteractions;
import infoHidingVisu.util.GraphHistoryUserProperties;
import infoHidingVisu.util.IGraphLayoutHistory;
import infoHidingVisu.visu.ShapeSelectionEvent;
import infoHidingVisu.visu.ShapeSelectionListener;
import vilog.common.data.ICluster;
import vilog.common.data.INode;
import visu.core.GLDrawer;
import visu.core.GLDrawerEventHandler;
import visu.core.VisualShape;

import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

/**
 * Created by seb on 2013-12-11.
 */
public class SoftVisuOverviewController extends GWShapesEventHandler implements ShapeSelectionListener {
    private final CodeHistoryController codeHistoryCtrl;

    public SoftVisuOverviewController(GLDrawer glDrawer, CodeHistoryController codeHistoryCtrl) {
        super(glDrawer);
        this.codeHistoryCtrl = codeHistoryCtrl;
        this.zoomingPanningEnabled = true;

        // create interactors
        //RectangularShapeSelector shapeSelector = new RectangularShapeSelector(glDrawer);
        //shapeSelector.addShapeSelectedListener(this);
        //this.glDrawer.addInteractor(shapeSelector);

        //this.glDrawer.addInteractor(new PopupMenuInteractor(glDrawer, codeHistoryCtrl));
    }


    public void shapeClicked(InputEvent e, VisualShape shape) {

        super.shapeClicked(e, shape);
    }

    @Override
    public void shapeHovered(InputEvent e, VisualShape shape) {
        super.shapeHovered(e,shape);
    }

    @Override
    public void shapeExited(InputEvent e, VisualShape shape) {
       super.shapeExited(e,shape);
    }


    @Override
    public void mousePressed(MouseEvent e) {

        super.mousePressed(e);

    }

    @Override
    public void mouseReleased(MouseEvent e) {
        super.mouseReleased(e);
    }


    @Override
    public void mouseMoved(MouseEvent e) {


        super.mouseMoved(e);

    }

    @Override
    public void shapeSelection(ShapeSelectionEvent event) {

    }


    @Override
    public void keyPressed(KeyEvent e) {


        if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {

            gw.setZoomAndPan(1,0,0);
            UserInteractions.getInstance().clearSelectionFilters();
            UserInteractions.getInstance().setSelectedClusterFilter(null);

            UserInteractions.getInstance().clearSelectedNodes();

            IGraphLayoutHistory.getInstance().clearCachedLayoutComputations();

            ClusterVisualShape.refreshAll();
            this.glDrawer.repaint();

        }

        super.keyPressed(e);


    }

    @Override
    public void shapeDragged(InputEvent e, VisualShape shape) {

        // Logger.getInstance().log(getClass(), "shape dragged="+shape,0);

        //save "fixed" positions of dragged items
        super.shapeDragged(e, shape);

        if (shape.getData() instanceof INode) {
            INode nodeShape = (INode) shape.getData();
            GraphHistoryUserProperties.getInstance().setNodePosition(nodeShape, shape.getLocation());

        } else if (shape.getData() instanceof ICluster) {
            ICluster clusterShape = (ICluster) shape.getData();

            for (INode child : clusterShape.getNodes()) {
                VisualShape vsChild = (VisualShape) child.getAttributeValue(VisualShapeAttributes.VISUAL_SHAPE);

                if (vsChild != null) {
                    // null if the shape is not a top level (not a class e.g., a field instance)

                    GraphHistoryUserProperties.getInstance().setNodePosition(child, vsChild.getLocation());
                }

            }

        }

    }



    }
