package softvis.views;

import infoHidingVisu.app.Constants;
import infoHidingVisu.codehistory.CodeHistoryController;
import infoHidingVisu.common.ISoftVisShapeConcreteCreator;
import infoHidingVisu.data.GraphImpl;
import infoHidingVisu.data.IGraphJsonExporter;
import infoHidingVisu.graphevolution.RevisionTime;
import infoHidingVisu.graphevolution.RevisionTimeSet;
import infoHidingVisu.shape.AbstractShapeLayout;
import infoHidingVisu.shape.VisualShapeAttributes;
import infoHidingVisu.util.IGraphLayoutHistory;
import infoHidingVisu.util.IGraphLayoutHistoryFilter;
import infoHidingVisu.util.JavaParserNamespace;
import infoHidingVisu.util.JavaParserUtil;
import softvis.shape.*;
import vilog.common.data.ICluster;
import vilog.common.data.IEdge;
import vilog.common.data.IGraph;
import vilog.common.data.INode;
import visu.core.*;

import java.awt.geom.Point2D;
import java.util.Iterator;

/**
 * Created by seb on 2013-12-11.
 */
public class SoftVisuOverviewLayout extends AbstractShapeLayout {
    private final GLDrawer drawer;
    private final CodeHistoryController codeHistoryCtrl;
    private VisualShapeCollection shapes;

    private LayoutAlgorithm layoutAlgo = new RandomLayoutAlgorithm() ;

    public SoftVisuOverviewLayout(GLDrawer drawer, CodeHistoryController codeHistoryCtrl) {
        super();
        this.drawer=drawer;
        this.codeHistoryCtrl=codeHistoryCtrl;

        shapes = new VisualShapeCollection();
    }

    @Override
    public VisualShapeCollection layoutShapes() {

        synchronized (this) {

                synchronized (shapes) {

                   // invalidate();

                    if (this.invalided == false && this.shapes != null)   {
                        return shapes;
                    }

                    shapes.clear();

                    // check if a project was loaded :
                    if (codeHistoryCtrl.getCodeHistory() != null) {

                        RevisionTimeSet revisionsRange = codeHistoryCtrl.getSelectedRevisions();

                        if (revisionsRange == null || revisionsRange.size() == 0) {
                            revisionsRange = new RevisionTimeSet();
                            revisionsRange.add(codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions().first());
                        }

                        long lastRev = revisionsRange.last().getRevision();

                        RevisionTime lastRevTime = codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions().getByRev(lastRev);
                        IGraph graphRev = codeHistoryCtrl.getGraph(lastRevTime);

                        if (graphRev == null)
                            return shapes; //not done yet or memory allocation issue ?

                        //Compute layout (if not cached already) for all graph revisions
                        for (RevisionTime rev : codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions()) {

                            IGraph graphAtRev = codeHistoryCtrl.getGraph(rev);

                            //IGraphLayoutHistory.getInstance().setForceAttracWeight(Constants.FORCE_ATTRACT_WEIGHT);

                            IGraphLayoutHistory.getInstance().setLayoutAlgo(layoutAlgo);
                            IGraphLayoutHistory.getInstance().computeLayout(drawer.getGlComponent().getBounds(), rev,
                                    graphAtRev, 100, JavaParserNamespace.CLASS_LEVEL,
                                    Constants.DESIGN_OPTIONS_FORCE_LAYOUT_ON_NEW_NODES_ONLY,
                                    new IGraphLayoutHistoryFilter() {
                                        @Override
                                        public boolean keepNewNodePosition(RevisionTime t, INode nodeAtVerT) {
                                            return Constants.DESIGN_OPTIONS_FORCE_LAYOUT_ON_NEW_NODES_ONLY;
                                        }
                                    });

                        }


                        IGraph graphRevCopy = new GraphImpl((GraphImpl) graphRev);

                        // Add shapes for the first revision of the graph
                        SoftVisShapeCreator shapeCreator = new SoftVisShapeCreator(drawer, shapes, new ISoftVisShapeConcreteCreator() {
                            @Override
                            public VisualShape createMethodShape(int i, int i2, int i3, int i4, INode iNode, VisualShapeCollection visualShapes, GLDrawer glDrawer) {
                                return new MethodNodeVisualShape2(i,i2,i3,i4,iNode,visualShapes,glDrawer);
                            }

                            @Override
                            public VisualShape createClassShape(int i, int i2, int i3, int i4, INode iNode, VisualShapeCollection visualShapes, GLDrawer glDrawer) {
                                return new ClassNodeVisualShape2(i,i2,i3,i4,iNode,visualShapes,glDrawer);
                            }

                            @Override
                            public VisualShape createPackageShape(int i, int i2, int i3, int i4, INode iNode, VisualShapeCollection visualShapes, GLDrawer glDrawer) {
                                return new PackageNodeVisualShape2(i,i2,i3,i4,iNode,visualShapes,glDrawer);
                            }

                            @Override
                            public VisualShape createEdgeShape(VisualShape visualShape, VisualShape visualShape2, IEdge iEdge, VisualShapeCollection visualShapes, GLDrawer glDrawer) {
                                EdgeVisualShape2 edge= new EdgeVisualShape2(visualShape, visualShape2,iEdge, visualShapes,glDrawer);
                                edge.setClusterLinksEnabled(false);
                                return edge;
                            }

                            @Override
                            public VisualShape createClusterShape(ICluster iCluster, VisualShapeCollection visualShapes, GLDrawer glDrawer) {
                                return new ClusterVisualShape2(iCluster,visualShapes,glDrawer);
                            }

                            @Override
                            public void started(IGraph iGraph) {

                            }

                            @Override
                            public void ended(IGraph iGraph) {

                            }

                            @Override
                            public VisualShape createFieldShape(int x, int y, int w, int h, INode node, VisualShapeCollection shapes, GLDrawer drawer) {
                                return null;
                            }

                        });
                        shapeCreator.createShapes(graphRevCopy);

                        //Move shapes of current graph in view to their positions

                        Iterator<INode> nodesIterator = graphRevCopy.nodesIterator();

                            while (nodesIterator.hasNext()) {

                                INode node = nodesIterator.next();

                                String nodeIdField = IGraphJsonExporter.getNodeIdField(node);

                                Point2D nodeComputedPos = IGraphLayoutHistory.getInstance().getNodePosition(nodeIdField, ""+node.getAttributeValue(nodeIdField), lastRevTime);

                                if (nodeComputedPos != null) {

                                    VisualShape vsNode = (VisualShape) node.getAttributeValue(VisualShapeAttributes.VISUAL_SHAPE);

                                    if (vsNode != null) {

                                            vsNode.moveTo ( nodeComputedPos.getX(), nodeComputedPos.getY());

                                    }

                                }
                            }


                    }


                    shapes.reorderByLayer();
                    this.drawer.repaint();

                    invalided = false;

            }

            return shapes;

        }

    }

    @Override
    public boolean shapeInsideTimePeriod(Long shapeRev, int timeperiodNo) {
        return false;
    }



    private class RandomLayoutAlgorithm extends AbstractLayoutAlgorithm {

        @Override
        public void computeShapePositions(int startIteration, int endIteration, boolean computeForNewNodesOnly) {


            Iterator<INode> nodeIterator = g.nodesIterator();

            while (nodeIterator.hasNext()) {
                INode node = nodeIterator.next();

                Integer nodeType = JavaParserUtil.getNodeTypeIdGeneric(node);

                if (nodeType == null) {
                    //Logger.debug("nodeType==" + nodeType);
                }
                else {

                    if (nodeType == JavaParserUtil.NODE_TYPE_CLASS ||
                            nodeType == JavaParserUtil.NODE_TYPE_ABSTRACT_CLASS ||
                            nodeType == JavaParserUtil.NODE_TYPE_INTERFACE ) {

                        setNodePosition(node, Math.random() * super.bounds.getWidth(), Math.random() * super.bounds.getHeight() );

                    }

                }

            }


        }


    }
}
