package softvis.views;

import graphics.GraphicsWrapper;
import infoHidingVisu.codehistory.CodeHistoryController;
import infoHidingVisu.shape.AbstractShapeGLDrawer;
import infoHidingVisu.visu.VisuTimelineController;
import infoHidingVisu.visu.VisuTimelineLayout;
import visu.core.GLDrawerEventHandler;
import visu.core.ShapeLayout;

/**
 * Created by seb on 2014-04-29.
 */
public class VisuTimelineDrawer2 extends AbstractShapeGLDrawer {

    private CodeHistoryController codeHistoryCtrl;
    private VisuTimelineLayout layout;

    public VisuTimelineDrawer2(CodeHistoryController codeHistoryCtrl) {
        this.codeHistoryCtrl=codeHistoryCtrl;
    }

    @Override
    protected GLDrawerEventHandler createEventHandler() {
        return new VisuTimelineController(this,codeHistoryCtrl);
    }

    @Override
    public GraphicsWrapper getGraphicsWrapper() {
        VisuTimelineController handler = (VisuTimelineController) this.getEventHandler();
        return handler.getGw();
    }

    @Override
    public ShapeLayout getLayout() {

        if (this.layout == null) {
            this.layout = new VisuTimelineLayout2(this, codeHistoryCtrl);
        }
        return this.layout;
    }
}
