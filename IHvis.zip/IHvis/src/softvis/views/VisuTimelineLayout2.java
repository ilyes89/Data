package softvis.views;

import infoHidingVisu.codehistory.CodeHistoryController;
import infoHidingVisu.graphevolution.RevisionChronology;
import infoHidingVisu.ui.DataPoint;
import infoHidingVisu.util.ClusterHistory;
import infoHidingVisu.util.StabilityPointMeasurerFactory;
import infoHidingVisu.visu.VisuTimelineLayout;
import softvis.shape.ContinuousLineVisualShape2;
import vilog.common.data.ICluster;
import visu.core.VisualShape;

import java.awt.*;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by seb on 2014-04-29.
 */
public class VisuTimelineLayout2 extends VisuTimelineLayout {

    public VisuTimelineLayout2(VisuTimelineDrawer2 visuTimelineDrawer2, CodeHistoryController codeHistoryCtrl) {

        super(visuTimelineDrawer2,codeHistoryCtrl);

    }




    protected List<DataPoint> getInstanceDataPoints(List<ClusterHistory.IClusterTimeRev>  clustersHistoryOfInstance, float timelineHeight, double timelineLabelW, RevisionChronology revisionsTimeslices, String typeEvolutionCluster, Color ihMecanismColor, double minClusterInstanceMetric, double maxClusterInstanceMetric) {


        // settings for drawing dots on the timeline
        float rectWidth = 8;
        float rectHeight = 8;
        float maxHeight = timelineHeight * 0.50f;

        // Get the list of points for this instance
        int idxDataPts = 0;
        List<DataPoint> lstInstanceDataPoints = new ArrayList<DataPoint>();
        for (ClusterHistory.IClusterTimeRev entryClustersOfInstance : clustersHistoryOfInstance) {

            // point at X = Timeline for t.
            // point at Y = sizeOfCluster mapped to a normalized scale.
            double posTimeSliceX = getTimelinePosition(entryClustersOfInstance.getRevTime(), timelineLabelW,revisionsTimeslices);

            if (posTimeSliceX < 0) {
                continue;
            }

            double posX = 0 * minSpaceBetweenTimespaceBars + posTimeSliceX - rectWidth / 2.0f;


            double clusterInstanceMetric = StabilityPointMeasurerFactory.getInstance().getClusterInstanceMetric(entryClustersOfInstance, typeEvolutionCluster, codeHistoryCtrl);

            double barRatio = 1f - (clusterInstanceMetric - minClusterInstanceMetric) / maxClusterInstanceMetric;
            double posY = (timelineY + spaceBetweenTimelineAndFirstRect) + maxHeight * barRatio;

            lstInstanceDataPoints.add(new DataPoint(entryClustersOfInstance, new Point2D.Double(posX, posY), new DataPointInfo(clusterInstanceMetric,typeEvolutionCluster,ihMecanismColor,rectHeight,rectWidth) ));


            idxDataPts++;

        }
        return lstInstanceDataPoints;
    }

    protected VisualShape createContinuousLine(ICluster firstClusterOfThisInstance, List<DataPoint> lstInstanceDataPoints) {
        VisualShape s;

        s = shapes.addShape(
                new ContinuousLineVisualShape2(lstInstanceDataPoints, firstClusterOfThisInstance, shapes, drawer)
        );

        return s;
    }


}
