package softvis.views;

import infoHidingVisu.app.Constants;
import infoHidingVisu.common.ISoftVisShapeConcreteCreator;
import infoHidingVisu.shape.VisualShapeAttributes;
import infoHidingVisu.util.IGraphLayoutHistory;
import infoHidingVisu.util.JavaParserNamespace;
import infoHidingVisu.util.JavaParserUnit;

import java.awt.*;
import java.util.Iterator;
import java.util.Stack;

import infoHidingVisu.util.JavaParserUtil;
import vilog.common.data.*;
import vilog.common.utils.Logger;
import visu.core.GLDrawer;
import visu.core.VisualShape;
import visu.core.VisualShapeCollection;

/**
 * Creates shapes for classes in a graph.
 * @author srufiange
 *
 */
public class SoftVisShapeCreator implements IGraphVisitor {
    private final ISoftVisShapeConcreteCreator concreteCreator;
    protected VisualShapeCollection shapes;
    protected Stack<VisualShape> stkParentShapes = new Stack<VisualShape>();
    protected GLDrawer drawer;

    public SoftVisShapeCreator(GLDrawer drawer, VisualShapeCollection shapes, ISoftVisShapeConcreteCreator concreteCreator) {
        this.drawer = drawer;
        this.shapes = shapes;
        this.concreteCreator=concreteCreator;
    }


    @Override
    public boolean visitEnterNode(INode node) {

        VisualShape vs = null;
        if (node.hasChildren()) {
            vs = createShape(node);
            if (vs != null)
                stkParentShapes.push( vs );
        }

        return true;
    }

    @Override
    public boolean visitLeaveNode(INode node) {

        //Add exiting node to the current top level node
        VisualShape nodeShape = null;
        if (node.hasChildren()) {

            if (stkParentShapes.isEmpty()) {
                //do not add this hierarchical node (not wanted by this shape creator)
            }
            else {

                //leaving a container : its shape has been built so add it to parent
                nodeShape =  stkParentShapes.pop();

                if (nodeShape != null) {


                    if (stkParentShapes.isEmpty()) {
                        addShape (nodeShape);
                    }
                    else {

                        VisualShape lastContainerShape = (VisualShape) stkParentShapes.peek();
                        lastContainerShape.addShape( nodeShape);

                    }
                }

            }


        }
        else {
            //leaving a leaf : create its shape and add it to parent
            nodeShape = createShape(node);

            if (nodeShape != null) {

                if (stkParentShapes.isEmpty()) {
                    addShape(nodeShape);
                }
                else {
                    VisualShape lastContainerShape = (VisualShape) stkParentShapes.peek();
                    lastContainerShape.addShape( nodeShape);
                }
            }
            else {
                //shape was not created for this node -e.g., might be a field (not to be visually displayed/unsupported)

            }
        }


        return true;
    }

    public VisualShape createShape(INode node) {

        VisualShape s = null;

        //String nodeName = (String) ((IGraphElement)node).getAttributeValue(Constants.ATTRIBUTE_NAMESPACE);
        //if (nodeName != null && nodeName.endsWith("SVNController:"))
        //Logger.getInstance().log(getClass(), "createShape - " + nodeName,0);

        //check if node already had a shape defined (reuse it)...
        VisualShape existingShape = null;//(VisualShape) node.getAttributeValue(VisualShapeAttributes.VISUAL_SHAPE);

        if (existingShape != null) {
            s = existingShape;
        }
        else {
            int drawerCenterX = (int) (drawer.getGlComponent().getBounds().getCenterX());
            int drawerCenterY = (int) (drawer.getGlComponent().getBounds().getCenterY());


            //boolean scopeNodeOut = new JavaParserNamespace((String) node.getAttributeValue(Constants.ATTRIBUTE_NAMESPACE)).getLevel() == 2;
            //int javaNameLevel = new JavaParserNamespace((String) node.getAttributeValue(Constants.ATTRIBUTE_NAMESPACE)).getLevel();


            Integer nodeTypeId = JavaParserUtil.getNodeTypeIdGeneric(node);

            //check node concrete type
            if (nodeTypeId == null || nodeTypeId == -1 || nodeTypeId == JavaParserUtil.NODE_TYPE_PACKAGE) {
                //package
                s = createPackageShape(drawerCenterX, drawerCenterY, 20, 20, node, shapes, drawer);
                //s.setAttribute(VisualShapeAttributes.COLOR, new Color(50,50,50,255) );
            }
            else if (nodeTypeId == JavaParserUtil.NODE_TYPE_INTERNAL_INTERFACE || nodeTypeId == JavaParserUtil.NODE_TYPE_INTERNAL_CLASS || nodeTypeId == JavaParserUtil.NODE_TYPE_CLASS || nodeTypeId == JavaParserUtil.NODE_TYPE_ABSTRACT_CLASS || nodeTypeId == JavaParserUtil.NODE_TYPE_INTERFACE ) {


                int x = (int) (drawer.getGlComponent().getBounds().getCenterX());
                int y = (int) (drawer.getGlComponent().getBounds().getCenterY());

                //class/interface type
                s = createClassShape(drawerCenterX, drawerCenterY, 20, 20, node, shapes, drawer);

                // s = createNodeShape(x, y, 20, 20, node, shapes, drawer);

                if (s != null) {
                    s.setAttribute(VisualShapeAttributes.COLOR, new Color(50, 50, 50, 255));
                    s.setAttribute(VisualShapeAttributes.LINE_WIDTH, 2.0f);
                    s.setAttribute(VisualShapeAttributes.TEXT_LINE_WIDTH, 1.0f);
                    s.setAttribute(VisualShapeAttributes.HOVERED_FILLED_SHAPE, true);
                    s.setAttribute(VisualShapeAttributes.TOOLTIP, "" + node.getAttributeValue(Constants.ATTRIBUTE_NAMESPACE));
                    s.setAttribute(VisualShapeAttributes.TOOLTIP_ATTRIBUTE, Constants.ATTRIBUTE_NAMESPACE);
                    s.setAttribute(VisualShapeAttributes.TOOLTIP_OFFSET_X, 0f);
                    s.setAttribute(VisualShapeAttributes.TOOLTIP_OFFSET_Y, 40f);

                    s.setAttribute(Constants.ATTRIBUTE_NAMESPACE, node.getAttributeValue(Constants.ATTRIBUTE_NAMESPACE));

                }



            }
            else if (nodeTypeId == JavaParserUtil.NODE_TYPE_METHOD || nodeTypeId == JavaParserUtil.NODE_TYPE_METHOD_CONSTRUCTOR) {
                //method

                s =  createMethodShape(drawerCenterX, drawerCenterY, 20, 20, node, shapes, drawer);
            }

            else if (nodeTypeId == JavaParserUtil.NODE_TYPE_FIELD) {
                s = createFieldShape(drawerCenterX, drawerCenterY, 20, 20, node, shapes, drawer);
            }
            else {

                Logger.getInstance().log(getClass(), "unhandled type id == " + nodeTypeId);
            }



            /*
            JavaParserUnit jpu = (JavaParserUnit) node.getAttributeValue(Constants.ATTRIBUTE_JAVAPARSER_UNIT);
            Object nodeImpl = node.getAttributeValue(Constants.ATTRIBUTE_IMPL);

            if (nodeImpl == null) {
                //package
                s = new PackageNodeVisualShape(drawerCenterX, drawerCenterY, 20, 20, node, shapes, drawer);
                //s.setAttribute(VisualShapeAttributes.COLOR, new Color(50,50,50,255) );
            }
            else if (nodeImpl instanceof MethodDeclaration || nodeImpl instanceof ConstructorDeclaration ) {
                //method

                s = new MethodNodeVisualShape(drawerCenterX, drawerCenterY, 20, 20, node, shapes, drawer);

            }
            else if (nodeImpl instanceof ClassOrInterfaceDeclaration) {
                //class/interface type
                s = new ClassNodeVisualShape(drawerCenterX, drawerCenterY, 20, 20, node, shapes, drawer);
            }
            */

            node.setAttributeValue(VisualShapeAttributes.VISUAL_SHAPE, s);
        }


        return s;
    }


    public VisualShape createShape(IEdge edge) {

        VisualShape s = null;

        // check if node already had a shape defined (reuse it)...
        VisualShape existingShape = null;// (VisualShape) edge.getAttributeValue(VisualShapeAttributes.VISUAL_SHAPE);

        if (existingShape != null) {
            s = existingShape;
        }
        else {


            VisualShape nodeInShape = (VisualShape) edge.getInNode().getAttributeValue(
                    VisualShapeAttributes.VISUAL_SHAPE);
            VisualShape nodeOutShape = (VisualShape) edge.getOutNode().getAttributeValue(
                    VisualShapeAttributes.VISUAL_SHAPE);

            s = createEdgeShape(nodeInShape, nodeOutShape, edge, shapes, drawer);

            // s.setAttribute(VisualShapeAttributes.COLOR, new Color(150,150,150,200) );
            edge.setAttributeValue(VisualShapeAttributes.VISUAL_SHAPE, s);

            /*
            VisualShape nodeInShape = (VisualShape) edge.getInNode().getAttributeValue(
                    VisualShapeAttributes.VISUAL_SHAPE);
            VisualShape nodeOutShape = (VisualShape) edge.getOutNode().getAttributeValue(
                    VisualShapeAttributes.VISUAL_SHAPE);

            boolean scopeNodeIn = new JavaParserNamespace((String) edge.getInNode().getAttributeValue(
                    Constants.ATTRIBUTE_NAMESPACE)).getLevel() == 2;
            boolean scopeNodeOut = new JavaParserNamespace((String) edge.getOutNode().getAttributeValue(
                    Constants.ATTRIBUTE_NAMESPACE)).getLevel() == 2;

            if (scopeNodeIn == false || scopeNodeOut == false) {
                // do not render edge - node is an internal class (e.g., out of agg point/level)
            }
            else if (nodeInShape != null && nodeInShape != null) {

                s = createEdgeShape(nodeInShape, nodeOutShape, edge, shapes, drawer);

                // s.setAttribute(VisualShapeAttributes.COLOR, new Color(150,150,150,200) );
                edge.setAttributeValue(VisualShapeAttributes.VISUAL_SHAPE, s);
            }
            else {
                Logger.getInstance().log(getClass(), "edge connecting with one null element : shaped skipped", 0);
            }

            */
        }

        return s;

    }

    public void createShapes(IGraph igraph) {

        shapes.clear();

        if (concreteCreator != null)
            concreteCreator.started(igraph);

        igraph.accept(this);

        // add edges between these nodes
        addEdges(igraph);

        // create shapes for the clusters...
        addClusters(igraph);

        if (concreteCreator != null)
            concreteCreator.ended(igraph);


    }

    private void addClusters(IGraph igraph) {

        for (ICluster cluster : igraph.getClusters()) {

            VisualShape clusterShape = createShape(cluster);
            addShape(clusterShape);

        }
    }

    private void addEdges(IGraph igraph) {

        Iterator<INode> nodeIterator = igraph.nodesIterator();

        while (nodeIterator.hasNext()) {
            INode node = nodeIterator.next();

            for (IEdge edgeOut : node.getOutgoingEdges()) {

                VisualShape shapeEdge = createShape(edgeOut);
                addShape(shapeEdge);

            }

        }

    }

    public void addShape(VisualShape vs) {

        if (vs != null) {

            /*
            if (new JavaParserNamespace(
                    (String) ((IGraphElement) vs.getData()).getAttributeValue(Constants.ATTRIBUTE_NAMESPACE))
                    .getLevel() <= JavaParserNamespace.CLASS_LEVEL) {
                this.shapes.addShape(vs);
            }
            else if (vs.getData() != null && vs.getData() instanceof ICluster) {
                // node is a cluster
                this.shapes.addShape(vs);
            }

*/
            this.shapes.addShape(vs);

            // vsNode.setAttribute(VisualShapeAttributes.VISIBLE, true);
        }
    }

    public void removeShape(VisualShape vs) {

        if (vs != null) {

            // String nodeName = (String) ((IGraphElement)vs.getData()).getAttributeValue(Constants.ATTRIBUTE_NAMESPACE);
            // if (nodeName != null && nodeName.endsWith("SVNController:"))
            // Logger.getInstance().log(getClass(), "aaa",0);
            // else
            // return;

            this.shapes.removeShape(vs);
        }
    }

    public VisualShape findShape(VisualShape searchVs) {
        return shapes.findShape(searchVs);
    }

    public VisualShape createShape(ICluster cluster) {

        VisualShape s = null;

        s = createClusterShape(cluster, shapes, drawer);
        cluster.setAttributeValue(VisualShapeAttributes.VISUAL_SHAPE, s);

        return s;

    }



    private VisualShape createMethodShape(int x, int y, int w, int h, INode node, VisualShapeCollection shapes, GLDrawer drawer) {
        return concreteCreator.createMethodShape(x, y, w, h, node, shapes, drawer);
    }

    private VisualShape createClassShape(int x, int y, int w, int h, INode node, VisualShapeCollection shapes, GLDrawer drawer) {
        return concreteCreator.createClassShape(x, y, w, h, node, shapes, drawer);
    }

    private VisualShape createPackageShape(int x, int y, int w, int h, INode node, VisualShapeCollection shapes, GLDrawer drawer) {
        return concreteCreator.createPackageShape(x, y, w, h, node, shapes, drawer);
    }


    private VisualShape createEdgeShape(VisualShape nodeInShape, VisualShape nodeOutShape, IEdge edge, VisualShapeCollection shapes, GLDrawer drawer) {
        return concreteCreator.createEdgeShape(nodeInShape, nodeOutShape, edge, shapes, drawer);
    }

    private VisualShape createClusterShape(ICluster cluster, VisualShapeCollection shapes, GLDrawer drawer) {
        return concreteCreator.createClusterShape(cluster, shapes, drawer);
    }

    private VisualShape createFieldShape(int x, int y, int w, int h, INode node, VisualShapeCollection shapes, GLDrawer drawer) {
        return concreteCreator.createFieldShape(x, y, w, h, node, shapes, drawer);
    }

}
