package softvis.views;

import graphics.GraphicsWrapper;
import infoHidingVisu.codehistory.CodeHistoryController;
import infoHidingVisu.graphics.GraphicsWrapper2;
import infoHidingVisu.shape.AbstractShapeGLDrawer;
import infoHidingVisu.visu.VisuIHOverviewController;
import visu.core.AbstractGLDrawer;
import visu.core.GLDrawer;
import visu.core.GLDrawerEventHandler;
import visu.core.ShapeLayout;

import javax.media.opengl.GLAutoDrawable;

/**
 * Created by seb on 2013-12-11.
 */
public class SoftVisuOverviewDrawer extends AbstractShapeGLDrawer {
    private final CodeHistoryController codeHistoryCtrl;
    private ShapeLayout layout;
    private GraphicsWrapper2 gw;

    public SoftVisuOverviewDrawer(CodeHistoryController codeHistoryCtrl) {
        this.codeHistoryCtrl = codeHistoryCtrl;
    }

    @Override
    public ShapeLayout getLayout() {

        if (this.layout == null)
            this.layout = new SoftVisuOverviewLayout(this, codeHistoryCtrl);

        return this.layout;

    }

    @Override
    protected GLDrawerEventHandler createEventHandler() {
        return new SoftVisuOverviewController(this,codeHistoryCtrl);
    }

    @Override
    public GraphicsWrapper getGraphicsWrapper() {
        if (gw == null) {
            gw = new GraphicsWrapper2();
            SoftVisuOverviewController handler = (SoftVisuOverviewController) this.getEventHandler();
            handler.gw = gw;
        }

        return gw;
    }


    @Override
    public void glDisplay(GLAutoDrawable drawable) {

        if (gl == null) return;

        this.zoomingMode = GraphicsWrapper2.ZOOM_MODE_SCALE;

        GraphicsWrapper2 gw2 = (GraphicsWrapper2) this.getGraphicsWrapper();

        super.glDisplay(drawable);

    }


}
