package softvis.shape;

import graphics.GraphicsWrapper;
import infoHidingVisu.app.Constants;
import infoHidingVisu.graphics.GraphicsWrapper2;
import infoHidingVisu.shape.ContinuousLineVisualShape;
import infoHidingVisu.shape.RectVisualShape;
import infoHidingVisu.shape.VisualShapeAttributes;
import infoHidingVisu.ui.DataPoint;
import infoHidingVisu.util.ClusterHistory;
import infoHidingVisu.util.JavaGraphUtil;
import infoHidingVisu.visu.VisuTimelineLayout;
import vilog.common.data.ICluster;
import visu.core.GLDrawer;
import visu.core.VisualShape;
import visu.core.VisualShapeCollection;

import javax.media.opengl.GL2;
import java.awt.*;
import java.awt.geom.Point2D;
import java.util.List;

public class ContinuousLineVisualShape2 extends ContinuousLineVisualShape {

    public ContinuousLineVisualShape2(List<DataPoint> lstDataPoints,
                                      Object data, VisualShapeCollection shapes, GLDrawer drawer) {

		super( lstDataPoints, data, shapes, drawer);

    }

    @Override
    public void setAppearance() {

        super.setAppearance();


        setAttribute(VisualShapeAttributes.TOOLTIP_FONT_HEIGHT, 9f);

        //tooltip position relative to this shape's bounds (getBounds)
        setAttribute(VisualShapeAttributes.TOOLTIP_OFFSET_X, 10f);
        setAttribute(VisualShapeAttributes.TOOLTIP_OFFSET_Y, 23f);

        setAttribute(VisualShapeAttributes.HOVERED_COLOR, new Color(50, 150, 64, 255));

    }
    @Override
    public void render(GraphicsWrapper gw) {

        if (isVisible() == false)
            return;

        GraphicsWrapper2 gw2 = (GraphicsWrapper2) gw;


        GL2 gl = gw2.getGL().getGL2();

        gl.glBegin(GL2.GL_LINE_STRIP);

        for (int idxPt = 0; idxPt < this.dataPoints.size() - 1;) {
            DataPoint dataPt = this.dataPoints.get(idxPt++);
            DataPoint nextDataPt = this.dataPoints.get(idxPt);

            gl.glVertex3d(dataPt.getX(), dataPt.getY(), 0);
            gl.glVertex3d(nextDataPt.getX(), nextDataPt.getY(), 0);

        }
        gl.glEnd();

        for (VisualShape vsDot : lstDots) {
            vsDot.preRender(gw);
            vsDot.setRenderingContext(gw);
            vsDot.render(gw);
        }

        drawLabel(this, gw2);

    }

    @Override
    protected void createDotShapes(GLDrawer drawer) {

        // Create shapes for dots (points)
        double lastPosX = -1;
        double lastPosY = -1;
        int idxDataPt = 0;

        for (DataPoint instanceDataPt : dataPoints) {

            double posX = instanceDataPt.getPoint().getX();
            double posY = instanceDataPt.getPoint().getY();
            ClusterHistory.IClusterTimeRev clusterAtT = (ClusterHistory.IClusterTimeRev) instanceDataPt.getData();

            VisuTimelineLayout.DataPointInfo dataPointInfo = (VisuTimelineLayout.DataPointInfo) instanceDataPt.getArg();

            double clusterInstanceMetric = dataPointInfo.getClusterInstanceMetric();//StabilityPointMeasurerFactory.getInstance().getClusterInstanceMetric(clusterAtT, typeEvolutionCluster, codeHistoryCtrl);

            // draw points the previous pos coord was different
            if (lastPosX < 0 || lastPosY < 0 || posY != lastPosY
                    || idxDataPt == dataPoints.size() - 1) {


                VisualShape s = new RectVisualShape(posX, posY, dataPointInfo.getRectHeight(), dataPointInfo.getRectWidth(), clusterAtT, new VisualShapeCollection(),
                        drawer);

                lstDots.addShape(s);

                s.setAttribute(VisualShapeAttributes.FILLED_SHAPE, true);

                String clusterTooltip = "";
                ICluster firstClusterOfThisInstance = clusterAtT.getClusterAtT();
                if (firstClusterOfThisInstance != null) {
                    clusterTooltip = (String) firstClusterOfThisInstance.getDefinedForNode().getAttributeValue(
                            Constants.ATTRIBUTE_NAMESPACE);
                }

                s.setAttribute(VisualShapeAttributes.TOOLTIP_FONT_HEIGHT, 9f);
                s.setAttribute(VisualShapeAttributes.TOOLTIP,
								/* "rev=" + clusterAtT.getRevTime() + "," + */"m " + "(" + dataPointInfo.getTypeEvolutionCluster() + ")" + "=" + clusterInstanceMetric + ", type="
                        + JavaGraphUtil.getClusterIHType(clusterAtT.getClusterAtT()) + ", cluster="
                        + clusterTooltip);


                //tooltip position relative to this shape's bounds (getBounds)

                s.setAttribute(VisualShapeAttributes.TOOLTIP_LOCATION, new Point2D.Double(
                        this.getBounds().getX() + 10f,
                        this.getBounds().getY() + 32f
                ));
                s.setAttribute(VisualShapeAttributes.TOOLTIP_OFFSET_X, 0f);
                s.setAttribute(VisualShapeAttributes.TOOLTIP_OFFSET_Y, 0f);

                Color ihMecanismColor = dataPointInfo.getIhMecanismColor();

                if (ihMecanismColor != null) {
                    s.setAttribute(VisualShapeAttributes.COLOR, new Color(ihMecanismColor.getRed(),
                            ihMecanismColor.getGreen(), ihMecanismColor.getBlue(), 128));
                    s.setAttribute(VisualShapeAttributes.BORDER_COLOR, new Color(ihMecanismColor.getRed(),
                            ihMecanismColor.getGreen(), ihMecanismColor.getBlue(), 255));
                    s.setAttribute(VisualShapeAttributes.HOVERED_COLOR, new Color(50, 150, 64, 255));
                    s.setAttribute(VisualShapeAttributes.HOVERED_FILLED_SHAPE, true);
                }
                else {


                    s.setAttribute(VisualShapeAttributes.HOVERED_FILLED_SHAPE, true);
                    s.setAttribute(VisualShapeAttributes.BORDER_COLOR, new Color(0, 0, 0, 255));
                    s.setAttribute(VisualShapeAttributes.HOVERED_COLOR, new Color(50, 150, 64, 255));

                }

                if (idxDataPt == 0) {
                    s.setAttribute(VisualShapeAttributes.SHAPE_TYPE, VisualShapeAttributes.SHAPE_TYPE_RECT);
                } else if (idxDataPt == dataPoints.size() - 1) {

                    s.setAttribute(VisualShapeAttributes.SHAPE_TYPE, VisualShapeAttributes.SHAPE_TYPE_CIRCLE);
                } else {
                    s.setAttribute(VisualShapeAttributes.SHAPE_TYPE, VisualShapeAttributes.SHAPE_TYPE_RECT);
                }
                // s.setAttribute(VisualShapeAttributes.COLOR, new
                // Color(0,0,0,0) );
                // s.setAttribute(VisualShapeAttributes.BORDER_COLOR,
                // new Color(0,0,0,0) );

                lastPosX = posX;
                lastPosY = posY;
            }

            idxDataPt++;

        } //end creation of dot shapes
    }



}
