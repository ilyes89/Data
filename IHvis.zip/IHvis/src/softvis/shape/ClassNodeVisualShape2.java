package softvis.shape;

import graphics.GraphicsWrapper;
import infoHidingVisu.shape.ClassNodeVisualShape;
import vilog.common.data.INode;
import visu.core.GLDrawer;
import visu.core.VisualShape;
import visu.core.VisualShapeCollection;

/**
 * Created by seb on 2014-02-02.
 */
public class ClassNodeVisualShape2 extends ClassNodeVisualShape {

    public ClassNodeVisualShape2(float x, float y, float w, float h, Object data, VisualShapeCollection shapesParent, GLDrawer drawer) {
        super(x, y, w, h, data, shapesParent, drawer);
    }


    @Override
    public void preRender(GraphicsWrapper gw) {
        super.preRender(gw);
    }

    @Override
    public void setAppearance() {
        super.setAppearance();
    }

    public void setRenderingContext(GraphicsWrapper gw) {

         super.setRenderingContext(gw);
    }

    @Override
    public void render(GraphicsWrapper gw) {
          super.render(gw);
    }


}
