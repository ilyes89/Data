package softvis.shape;

import graphics.GraphicsWrapper;
import infoHidingVisu.shape.ClusterVisualShape;
import vilog.common.data.ICluster;
import visu.core.GLDrawer;
import visu.core.VisualShape;
import visu.core.VisualShapeCollection;

/**
 * Created by seb on 2014-02-02.
 */
public class ClusterVisualShape2 extends ClusterVisualShape {

    public ClusterVisualShape2(Object data, VisualShapeCollection shapesParent, GLDrawer drawer) {
        super(data, shapesParent, drawer);
    }


    @Override
    public void preRender(GraphicsWrapper gw) {
        super.preRender(gw);
    }

    @Override
    public void setAppearance() {
        super.setAppearance();
    }

    public void setRenderingContext(GraphicsWrapper gw) {

        super.setRenderingContext(gw);
    }

    @Override
    public void render(GraphicsWrapper gw) {
          super.render(gw);
    }

}
