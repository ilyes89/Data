package softvis.shape;

import graphics.GraphicsWrapper;
import infoHidingVisu.shape.MethodNodeVisualShape;
import visu.core.GLDrawer;
import visu.core.VisualShapeCollection;

/**
 * Created by seb on 2014-02-02.
 */
public class MethodNodeVisualShape2 extends MethodNodeVisualShape {

    public MethodNodeVisualShape2(float x, float y, float w, float h, Object data, VisualShapeCollection shapesParent, GLDrawer drawer) {
        super(x, y, w, h, data, shapesParent, drawer);
    }


    @Override
    public void preRender(GraphicsWrapper gw) {
        super.preRender(gw);
    }

    @Override
    public void setAppearance() {
        super.setAppearance();
    }

    public void setRenderingContext(GraphicsWrapper gw) {

        super.showIds = false;
        super.setRenderingContext(gw);
    }

    @Override
    public void render(GraphicsWrapper gw) {
         super.render(gw);
    }

}
