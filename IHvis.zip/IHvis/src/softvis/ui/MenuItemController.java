package softvis.ui;

import infoHidingVisu.change.CodeChange;
import infoHidingVisu.codehistory.CodeHistoryController;
import infoHidingVisu.graphevolution.GraphChange;
import infoHidingVisu.graphevolution.GraphChangeHistory;
import infoHidingVisu.graphevolution.GraphChangeList;
import infoHidingVisu.graphevolution.RevisionTime;
import infoHidingVisu.graphevolution.generic.AddClusterGenericGraphChange;
import infoHidingVisu.graphevolution.generic.ModClusterGenericGraphChange;
import infoHidingVisu.graphevolution.generic.RemClusterGenericGraphChange;
import infoHidingVisu.util.IGraphHistoryUtil;
import infoHidingVisu.util.JavaParserUtil;
import infoHidingVisu.util.StabilityPointMeasurerFactory;
import sun.util.calendar.BaseCalendar;
import vilog.common.data.*;
import vilog.common.utils.ListUtil;
import vilog.common.utils.Logger;
import vilog.net.RepositoryChange;
import vilog.plugin.SourceTypeMapper;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by seb on 2014-01-08.
 */
public class MenuItemController implements ActionListener {

    private final CodeHistoryController codeHistoryCtrl;
    private Integer cmdChoiceClusterId;

    public MenuItemController(CodeHistoryController codeHistoryCtrl) {

        this.codeHistoryCtrl = codeHistoryCtrl;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        String cmdName = e.getActionCommand();
        FileWriter file = null;
        Logger.debug("Begin - Command " + cmdName);

        // check if a project was loaded
        if (codeHistoryCtrl.getCodeHistory() == null) {
            Logger.getInstance().log(getClass(), "Load a project first.", 0);
            return;
        }

        if (cmdName.equals("DisplayChangeHistory")) {

            //Browse the change history (e.g., to find in which commits a file named *PATTERN* was changed)

            for (RevisionTime rev : codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions()) {
                IGraph softwareGraphAtRevision = codeHistoryCtrl.getGraph(rev);

                if (softwareGraphAtRevision.getClusters().size() > 0) {

                RepositoryChange repositoryChange = codeHistoryCtrl.getCodeHistory().getRepositoryChange(rev);

                GraphChangeList graphChanges = codeHistoryCtrl.getCodeHistory().getGraphChange(rev);

                List<CodeChange> codeChanges = codeHistoryCtrl.getCodeHistory().getCodeChangesInTransaction(rev);

                //Output revision infos
                Logger.debug("Begin - Revision #" + rev.toString() + " >>>>>> ");

                Logger.debug("Infos: " + repositoryChange.toString());
                Logger.debug("Software Graph : " + softwareGraphAtRevision.getNodes().size() + " nodes (e.g., classes,methods) " + " and " + softwareGraphAtRevision.getEdges().size() + " edges (e.g., couplings) " + " and " + softwareGraphAtRevision.getClusters().size() + " clusters (e.g., variability zones) ");
                Logger.debug("List of graph changes: " + graphChanges);
                Logger.debug("List of code changes: " + ListUtil.listToString(codeChanges));




                //Output the graph structure
                //Logger.debug("Graph Structure >>> ");
                //softwareGraphAtRevision.accept(new ConsoleIGraphVisitor(true));
                //Logger.debug("Graph Structure <<< ");


                //Browse graph
                for (INode node : softwareGraphAtRevision.getNodes()) {

                    String nodeType = (String) node.getAttributeValue("nodeType");
                    //node.getAttributes();

                    if (nodeType != null) {

                        if (nodeType.equals(JavaParserUtil.NODE_TYPE_CLASS)) {
                            //
                        }
                    }


                }

                //Browse graph - search class with fixed name
                INode findNode = softwareGraphAtRevision.findNodeAttributeValueExact("ROOT", "name");


                Logger.debug("End - Revision #" + rev.toString() + " <<<<<< ");


            }

        }
        } else if (cmdName.equals("DisplayStabilityPointsList")) {



            for (RevisionTime rev : codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions()) {

                IGraph softwareGraphAtRevision = codeHistoryCtrl.getGraph(rev);

                Logger.debug("Begin - Revision #" + rev.toString() + " >>>>>> ");

                for (ICluster cluster : softwareGraphAtRevision.getClusters()) {

                    INode clusterDefinedForNode = cluster.getDefinedForNode();
                    String clusterDefinedForNodeName = (String) clusterDefinedForNode.getAttributeValue("name");

                    Logger.debug("stability point key node: " + clusterDefinedForNodeName);
                    Logger.debug("stability point zone members: " + ListUtil.listToString(cluster.getNodes(), new ListUtil.ObjectToString() {

                        @Override
                        public String itemToString(Object item) {
                            INode node = (INode) item;
                            Object name = node == null ? "" : node.getAttributeValue("name");
                            return name == null ? "" : (String) name;
                        }

                    }));


                    Map<String, String> mapMetrics = (Map<String, String>) cluster.getAttributeValue("mapMetrics");

                    // Logger.debug("stability point metrics: " + mapMetrics.toString());


                    //To get more details about some metrics :

                    //N (or A) - nb of elements inside the variability zone
                    List<IGraphElement> nodesInsideVariabilityZone = new ArrayList<IGraphElement>();

                    double NAmetric = StabilityPointMeasurerFactory.getInstance().getClusterInstanceMetric(cluster, rev, "A", codeHistoryCtrl, nodesInsideVariabilityZone);

                    List<IGraphElement> internalCouplings = new ArrayList<IGraphElement>();
                    double Bmetric = StabilityPointMeasurerFactory.getInstance().getClusterInstanceMetric(cluster, rev, "B", codeHistoryCtrl, internalCouplings);

                    List<IGraphElement> externalCouplings = new ArrayList<IGraphElement>();
                    double Cmetric = StabilityPointMeasurerFactory.getInstance().getClusterInstanceMetric(cluster, rev, "C", codeHistoryCtrl, externalCouplings);

                    //U (or D) - incoming couplings to elements inside the variability zone
                    List<IGraphElement> nodesToVariabilityZone = new ArrayList<IGraphElement>();
                    double UDmetric = StabilityPointMeasurerFactory.getInstance().getClusterInstanceMetric(cluster, rev, "D", codeHistoryCtrl, nodesToVariabilityZone);

                    //S (or E) - incoming couplings to the interface (stability point)
                    List<IGraphElement> nodesToStabilityPoint = new ArrayList<IGraphElement>();
                    double SEmetric = StabilityPointMeasurerFactory.getInstance().getClusterInstanceMetric(cluster, rev, "E", codeHistoryCtrl, nodesToStabilityPoint);


                    //---

                    Logger.debug("End Cluster << ");

                }

                Logger.debug("End - Revision #" + rev.toString() + " <<<<<< ");

            }


        } else if (cmdName.equals("ExportDataTest")) {


            //print list of all clusters
            for (ICluster cluster : codeHistoryCtrl.getAllClusters(true)) { //true to reload the cache
                Logger.debug("key node: " + cluster.getDefinedForNode().getAttribute("name", ""));
            }

            GraphChangeHistory graphChangeHistory = codeHistoryCtrl.getCodeHistory();

            for (RevisionTime t : graphChangeHistory.getTimeslices().getAllRevisions()) {


                GraphChangeList graphChangeList = graphChangeHistory.getGraphChange(t);

                //Exemple : le nouveau cluster CommandChoice est ajouté à la révision 2 jusqu'à la révision 7.
                //Aussi, à la révision 7, il est modifié (un second noeud y est ajouté)
                //à la révision 22, le cluster est supprimé

                //Pour ce faire, nous créons les clusters à chaque révision (pour les afficher maintenant)
                //Nous exportons deux événements : création du cluster à la révision 2 et modification de ce cluster à la révision 7.

                //Ajouts de clusters
                if (t.getRevision() >= 2 && t.getRevision() <= 22) {

                    //Création du cluster pour affichage dans la vue courante
                    IGraph graphAtT = codeHistoryCtrl.getGraph(t);
                    INode keyNode = graphAtT.findNodeAttributeValueExact("CH.ifa.draw.util:CommandChoice:", "name");
                    INode insideNode1 = graphAtT.findNodeAttributeValueExact("CH.ifa.draw.util:Command:", "name");

                    ICluster cmdChoiceCluster = graphAtT.addCluster( keyNode, new NodeCollection(graphAtT.getGraphMapper(),insideNode1), null);

                    //Exporte l'événement 'nouveau cluster ajouté à la révision 2'
                    if (t.getRevision() == 2) {
                        cmdChoiceClusterId = cmdChoiceCluster.getId();
                        GraphChange addClusterGraphChange = createGraphChangeAddCluster(cmdChoiceClusterId, cmdChoiceCluster);
                        graphChangeList.add ( addClusterGraphChange );
                    }

                }

                //Modifications de clusters
                if (t.getRevision() >= 7 && t.getRevision() <= 22) {

                    IGraph graphAtT = codeHistoryCtrl.getGraph(t);

                    //Get cluster to be modified
                    INode keyNode = graphAtT.findNodeAttributeValueExact("CH.ifa.draw.util:CommandChoice:", "name");
                    ICluster modifiedCmdChoiceCluster = graphAtT.getClustersDefinedForNode( keyNode ).iterator().next();

                    //Add a new node inside that cluster
                    INode insideNode2 = graphAtT.findNodeAttributeValueExact("CH.ifa.draw.standard:AlignCommand:", "name");
                    modifiedCmdChoiceCluster.getNodes().add( insideNode2 );

                    if (t.getRevision() == 7) {

                        //Generate event : 'modify cluster' (which now contains a new element) at revision 7
                        GraphChange modClusterGraphChange = createGraphChangeModCluster(cmdChoiceClusterId, modifiedCmdChoiceCluster);
                        graphChangeList.add ( modClusterGraphChange );

                    }

                }

                //Suppressions de clusters


                if (t.getRevision() == 22) {

                    IGraph graphAtT = codeHistoryCtrl.getGraph(t);

                    //Get cluster to be modified
                    INode keyNode = graphAtT.findNodeAttributeValueExact("CH.ifa.draw.util:CommandChoice:", "name");
                    ICluster removedCmdChoiceCluster = graphAtT.getClustersDefinedForNode( keyNode ).iterator().next();
                    graphAtT.removeCluster(removedCmdChoiceCluster);

                    //Generate event : 'remove cluster' at revision 22
                    GraphChange remClusterGraphChange = createGraphChangeDelCluster(cmdChoiceClusterId, removedCmdChoiceCluster);
                    graphChangeList.add ( remClusterGraphChange );

                }



            }

            //Export results into test json file.

            if (false)
                return;

            String targetFileName = "data/jhotdraw6-test.json";

            IGraphHistoryUtil.graphHistoryToJson(
                    codeHistoryCtrl,
                    codeHistoryCtrl.getCodeHistory()
                    , targetFileName
            );

        }


        else if (cmdName.equals("GenerateJson")) {
            //Generate new Json file for new SVN
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH-mm");
            Date date = new Date();
            String targetFileName = "C:/Users/Elyes/IdeaProjects/softvis-variability/data/NewJson-export-"+dateFormat.format(date).toString()+".json";

            IGraphHistoryUtil.graphHistoryToJson(
                    codeHistoryCtrl,
                    codeHistoryCtrl.getCodeHistory()
                    , targetFileName
            );

        }

        else if (cmdName.equals("DisplayPremInformation")){

            RevisionTime rev = codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions().last();
            IGraph softwareGraphAtRevision = codeHistoryCtrl.getGraph(rev);
            int nbInterface = 0;
            int nbClass = 0;
            int nbInternalClass = 0;
            int nbField = 0 ;
            int nbMethod = 0;
            int nbAbstractClass = 0;

            for(INode node : softwareGraphAtRevision.getNodes()){

                String nodeType = (String) node.getAttributeValue("nodeType");
                if (nodeType != null) {

                    if (nodeType.equals("NODE_TYPE_INTERFACE")) {
                        nbInterface++;
                    }
                    else if (nodeType.equals("NODE_TYPE_CLASS")) {
                        nbClass++;
                    }
                    else if (nodeType.equals("NODE_TYPE_FIELD")) {
                        nbField++;
                    }
                    else if (nodeType.equals("NODE_TYPE_METHOD")) {
                        nbMethod++;
                    }
                    else if (nodeType.equals("NODE_TYPE_ABSTRACT_CLASS")) {
                        nbAbstractClass++;
                    }else if (nodeType.equals("NODE_TYPE_INTERNAL_CLASS")) {
                        nbInternalClass++;
                    }


                }
            }

            System.out.println("\tnumber of INTERFACE : "+nbInterface);
            System.out.println("\tnumber of CLASS : "+nbClass);
            System.out.println("\tnumber of ABSTRACT_CLASS : "+nbAbstractClass);
            System.out.println("\tnumber of INTERNAL_CLASS : "+nbInternalClass);
            System.out.println("\tnumber of FIELD : "+nbField);
            System.out.println("\tnumber of METHOD : "+nbMethod);
            System.out.println("***********************************************");
            //affichage des zones de variabilités
            System.out.println("Number of Variability_Zone : "+softwareGraphAtRevision.getClusters().size());
            System.out.println("---------------------------------------------------------------------------");

            for ( RevisionTime revision : codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions() ){
                softwareGraphAtRevision = codeHistoryCtrl.getGraph(revision);
                if (softwareGraphAtRevision.getClusters().size() >0){

                    System.out.println("rev "+revision.getRevision().intValue()+","+softwareGraphAtRevision.getClusters().size());
                }

            }



        }
        else if(cmdName.equals("Hypothesis")) {

            boolean h1 ;
            boolean h2 = true;
            boolean h3 = true;
            ICluster clusterTreated;
            IGraph softwareGraph;
            IGraph softwareGraph1;
            int nbImpl,nbNodesIn ;

            RevisionTime rev = codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions().last();
            softwareGraph = codeHistoryCtrl.getGraph(rev);

            String Header_file = "Stability point,Hyp 1,Hyp 2,Hyp3";
            try {
                file  = new FileWriter("C:/Users/Elyes/hypothesis.csv", true);
                file.write(Header_file);
                file.append("\n");


            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
                    for (ICluster cluster : softwareGraph.getClusters()) {

                        clusterTreated = cluster;
                        int lastSize = cluster.getNodes().size();
                        int firstSize = -1;
                        nbImpl = 0;
                        nbNodesIn=0;
                        h1=false;
                        int nbFirstallClient = -1;
                        int nblastAllClient = 0;
                        int nblastInstable=0;
                        int nbFirstInstable = -1;
                        String result = cluster.getDefinedForNode().getAttributeValue("name")+",";
                        //System.out.println(cluster.getDefinedForNode().getAttributeValue("name"));
                            for (RevisionTime revision : codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions()) {
                                softwareGraph1 = codeHistoryCtrl.getGraph(revision);
                                if (softwareGraph1.getClusters().size() > 0) {

                                    for (ICluster cluster1 : softwareGraph1.getClusters()) {
                                        if(clusterTreated.getDefinedForNode().getAttributeValue("name").equals(cluster1.getDefinedForNode().getAttributeValue("name")) && firstSize==-1)
                                        {
                                            firstSize=cluster1.getNodes().size();
                                        }

                                        if(clusterTreated.getDefinedForNode().getAttributeValue("name").equals(cluster1.getDefinedForNode().getAttributeValue("name")) && cluster1.getNodes().size()>nbNodesIn)
                                        {
                                            nbImpl+=1;
                                            nbNodesIn=cluster1.getNodes().size();
                                            h1=true;


                                        }


                                        else if (clusterTreated.getDefinedForNode().getAttributeValue("name").equals(cluster1.getDefinedForNode().getAttributeValue("name")) && cluster1.getNodes().size()<nbNodesIn){

                                            h1=false;
                                        }
                                            //clusterTreated=cluster1;


                                    }
                                 if(nbImpl>0 && h1==false )
                                 {
                                     try {
                                         file.append(result + "false,");

                                     } catch (IOException e1) {
                                         e1.printStackTrace();
                                     }
                                     break;
                                 }else if(firstSize!=lastSize && h1==true && revision.getRevision().intValue()==codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions().last().getRevision().intValue()){
                                     try {
                                         file.append(result + "true,");

                                     } catch (IOException e1) {
                                         e1.printStackTrace();
                                     }
                                 }
                                    else if(firstSize==lastSize && revision.getRevision().intValue()==codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions().last().getRevision().intValue())
                                 {
                                     try {
                                         file.append(result + "false,");

                                     } catch (IOException e1) {
                                         e1.printStackTrace();
                                     }
                                 }
                                }

                            }

                        for (RevisionTime revision : codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions()) {
                            softwareGraph1 = codeHistoryCtrl.getGraph(revision);
                            int totalclient=0;
                            if (softwareGraph1.getClusters().size() > 0) {

                                for (ICluster cluster1 : softwareGraph1.getClusters()) {
                                    if(cluster1.getDefinedForNode().getAttributeValue("name").equals(cluster.getDefinedForNode().getAttributeValue("name"))){

                                        for(IEdge edge : cluster1.getDefinedForNode().getIncomingEdges()){
                                            if(edge.getInNode()!=cluster1.getDefinedForNode() && !cluster1.getNodes().contains(edge.getInNode()))
                                              totalclient++;
                                        }
                                        if(nbFirstallClient==-1) {
                                            nbFirstallClient = totalclient;
                                            nblastAllClient=totalclient;
                                        }
                                        else if (totalclient>nblastAllClient)
                                        {
                                            h2=true;
                                            nblastAllClient=totalclient;
                                        }
                                        else if(totalclient<nblastAllClient)
                                        {
                                            h2=false;
                                            break;
                                        }
                                    }
                                }
                                if(h2==true && totalclient>nbFirstallClient &&  revision.getRevision().intValue()==codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions().last().getRevision().intValue())
                                {
                                    try {
                                        file.append( "true,");

                                    } catch (IOException e1) {
                                        e1.printStackTrace();
                                    }
                                }
                                if(h2==false){

                                    try {
                                        file.append( "false,");

                                    } catch (IOException e1) {
                                        e1.printStackTrace();
                                    }
                                    break;

                                }
                                if(nbFirstallClient==totalclient && revision.getRevision().intValue()==codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions().last().getRevision().intValue())
                                {
                                    try {
                                        file.append( "false,");

                                    } catch (IOException e1) {
                                        e1.printStackTrace();
                                    }
                                }
                            }
                        }

                        for (RevisionTime revision : codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions()) {
                            softwareGraph1 = codeHistoryCtrl.getGraph(revision);
                            int totalInstableClient=0;
                            List<INode> tabAllClient  = new ArrayList<INode>();

                            if (softwareGraph1.getClusters().size() > 0) {

                                for (ICluster cluster1 : softwareGraph1.getClusters()) {
                                    if(cluster1.getDefinedForNode().getAttributeValue("name").equals(cluster.getDefinedForNode().getAttributeValue("name"))) {

                                        for(IEdge edge : cluster1.getDefinedForNode().getIncomingEdges()){
                                            if(edge.getInNode()!=cluster1.getDefinedForNode() && !cluster1.getNodes().contains(edge.getInNode()) && !tabAllClient.contains(edge.getInNode()))
                                                tabAllClient.add(edge.getInNode());
                                        }

                                        for(INode client : tabAllClient){

                                            for(IEdge edge : client.getOutgoingEdges())
                                            {
                                                if(  cluster1.getNodes().contains(edge.getOutNode()))
                                                    totalInstableClient++;
                                            }

                                        }

                                        if(nbFirstInstable==-1){
                                           nblastInstable=totalInstableClient;
                                            nbFirstInstable=totalInstableClient;

                                        }else if (totalInstableClient<nblastInstable){
                                            h3=true;
                                            nblastInstable=totalInstableClient;
                                        }else if(totalInstableClient>nblastInstable){
                                            h3=false;
                                            break;
                                        }


                                    }
                                }

                                if(h3==true && totalInstableClient<nbFirstInstable &&  revision.getRevision().intValue()==codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions().last().getRevision().intValue())
                                {
                                    try {
                                        file.append( "true");
                                        file.append("\n");
                                    } catch (IOException e1) {
                                        e1.printStackTrace();
                                    }
                                }
                                if(h3==false){

                                    try {
                                        file.append( "false");
                                        file.append("\n");
                                    } catch (IOException e1) {
                                        e1.printStackTrace();
                                    }
                                    break;
                                }
                                if(nbFirstInstable==totalInstableClient && revision.getRevision().intValue()==codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions().last().getRevision().intValue())
                                {
                                    try {
                                        file.append( "false");
                                        file.append("\n");
                                    } catch (IOException e1) {
                                        e1.printStackTrace();
                                    }
                                }

                            }
                        }




                     }
            try {
                file.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }


        }

        else if (cmdName.equals("generateAllClients")) {

            FileWriter fileData = null ;
            FileWriter fileEvolution = null ;
            //get all stability point in the current project
            List<String> allStabilityPoints = new ArrayList<String>();
            RevisionTime revision = codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions().last();
            IGraph softwareGraphAtRevision = codeHistoryCtrl.getGraph(revision);
            for(ICluster cluster : softwareGraphAtRevision.getClusters()){

                String clusterDefinedNode = cluster.getDefinedForNode().getAttributeValue("name").toString();
                String stabilityPointName = clusterDefinedNode.substring(clusterDefinedNode.indexOf(":")+1,clusterDefinedNode.length()-1);
                if(!allStabilityPoints.contains(stabilityPointName))
                    allStabilityPoints.add(stabilityPointName);
            }

            int i=1;
            for (ICluster cluster : softwareGraphAtRevision.getClusters()){

                System.out.println(i+"="+cluster.getDefinedForNode().getAttributeValue("name").toString());
                i++;

            }

            for(String stabilityPoint : allStabilityPoints){

                try {
                    fileData = new FileWriter("C:/Users/Elyes/stabilityPoint/rhino/1.7_R4/evolution/"+stabilityPoint+"_evolution.txt", true);
                    fileData.write("\n");
                    fileEvolution = new FileWriter("C:/Users/Elyes/stabilityPoint/rhino/1.7_R4/sp/"+stabilityPoint+".txt", true);

                } catch (IOException e1) {
                    e1.printStackTrace();
                }

                List<INode> oldStableClientList = new ArrayList<INode>();
                List<INode> currentStableClientList = new ArrayList<INode>();
                List<INode> oldUnstableClientList = new ArrayList<INode>();
                List<INode> currentUnstableClientList = new ArrayList<INode>();
                List<INode> allClientsToStabilityPoint = new ArrayList<INode>();

                List<INode> finalStableClientList = new ArrayList<INode>();
                List<INode> finalUnstableClientList = new ArrayList<INode>();
                boolean isFirstCommit = true ;
                List<INode> listRedundantSP = new ArrayList<INode>();
                for (RevisionTime rev : codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions()) {
                    IGraph softwareGraph = codeHistoryCtrl.getGraph(rev);

                    if (softwareGraph.getClusters().size() > 0 ) {

                        for(ICluster cluster : softwareGraph.getClusters()){

                            INode currentStabilityPoint = cluster.getDefinedForNode();
                            String currentSP = currentStabilityPoint.getAttributeValue("name").toString() ;
                            if(currentSP.substring(currentSP.indexOf(":")+1,currentSP.length()-1).equals(stabilityPoint)){

                                if(listRedundantSP.size()==0)
                                    listRedundantSP.add(currentStabilityPoint);
                                else if (listRedundantSP.size()>0 && !listRedundantSP.contains(currentStabilityPoint))
                                {
                                    listRedundantSP.clear();
                                    listRedundantSP.add(currentStabilityPoint);
                                }
                            }
                        }

                        for(ICluster cluster : softwareGraph.getClusters()){
                            INode currentStabilityPoint = cluster.getDefinedForNode();
                            String currentSP = currentStabilityPoint.getAttributeValue("name").toString() ;
                            String shortSPName = currentSP.substring(currentSP.indexOf(":")+1,currentSP.length()-1);
                            if( shortSPName.equals(stabilityPoint)&& currentStabilityPoint.getIncomingEdges().size()>0  && listRedundantSP.contains(currentStabilityPoint) ){

                                if(isFirstCommit){
                                    //fill allClientsToStabilityPoint with all clients coupled to the interface
                                    for(IEdge edgeToStablityPoint  : currentStabilityPoint.getIncomingEdges()){

                                        if(edgeToStablityPoint.getInNode()!=currentStabilityPoint && ! cluster.getNodes().contains(edgeToStablityPoint.getInNode())) //parfois le point de stabilité a un selfedge
                                        {
                                            allClientsToStabilityPoint.add(edgeToStablityPoint.getInNode());
                                        }
                                    }

                                   //fill list of all unstable clients
                                    for(INode client : allClientsToStabilityPoint){

                                        for(IEdge edge : client.getOutgoingEdges())
                                        {
                                            if( ! oldUnstableClientList.contains(client)  && cluster.getNodes().contains(edge.getOutNode()))
                                                oldUnstableClientList.add(client);
                                        }
                                    }

                                    //fill list of all stable clients
                                    for(INode client : allClientsToStabilityPoint){

                                        if(!oldUnstableClientList.contains(client))
                                            oldStableClientList.add(client);
                                    }


                                    try {
                                        fileData.append("evolution du point de stabilité " + stabilityPoint + "\n");
                                        fileData.append("----------------------"+codeHistoryCtrl.getCodeHistory().getRepositoryChange(rev).getLogMessage().replace("\n", " ").replace("\r", " ")+"---------------\n");
                                        fileData.append("Liste des clients stables : \n");
                                        for (INode node : oldStableClientList){
                                            fileData.append("\t"+node.getAttributeValue("name").toString()+"\n");
                                            finalStableClientList.add(node);
                                        }
                                        fileData.append("Liste des clients instables : \n");
                                        for (INode node : oldUnstableClientList){
                                            fileData.append("\t"+node.getAttributeValue("name").toString()+"\n");
                                            finalUnstableClientList.add(node);
                                        }
                                    } catch (IOException e1) {
                                        e1.printStackTrace();
                                    }

                                    isFirstCommit = false ;

                                }

                                else {

                                    try {
                                        fileData.append("----------------------"+codeHistoryCtrl.getCodeHistory().getRepositoryChange(rev).getLogMessage().replace("\n", " ").replace("\r", " ")+"---------------\n");
                                        //fileData.append(codeHistoryCtrl.getCodeHistory().getCodeChangesInTransaction(rev).toString());

                                    } catch (IOException e1) {
                                        e1.printStackTrace();
                                    }
                                    allClientsToStabilityPoint.clear();
                                    currentStableClientList.clear();
                                    currentUnstableClientList.clear();
                                    for(IEdge edgeToStablityPoint  : currentStabilityPoint.getIncomingEdges()){

                                        if(edgeToStablityPoint.getInNode()!=currentStabilityPoint && ! cluster.getNodes().contains(edgeToStablityPoint.getInNode())) //parfois le point de stabilité a un selfedge
                                        {
                                            allClientsToStabilityPoint.add(edgeToStablityPoint.getInNode());
                                        }
                                    }

                                    //Check for new unstable clients
                                    for(INode client : allClientsToStabilityPoint){

                                        for(IEdge edge : client.getOutgoingEdges())
                                        {
                                            if( ! oldUnstableClientList.contains(client) && !currentUnstableClientList.contains(client)  && cluster.getNodes().contains(edge.getOutNode())) {
                                                try {
                                                    fileData.append("Ajout du client instable : "+client.getAttributeValue("name").toString()+"\n");
                                                    currentUnstableClientList.add(client);
                                                    finalUnstableClientList.add(client);
                                                } catch (IOException e1) {
                                                    e1.printStackTrace();
                                                }
                                            }
                                            else if ( oldUnstableClientList.contains(client) && !currentUnstableClientList.contains(client)   && cluster.getNodes().contains(edge.getOutNode())) {
                                                currentUnstableClientList.add(client);
                                                oldUnstableClientList.remove(client);
                                            }

                                        }
                                    }

                                    for(INode node : oldUnstableClientList){
                                        try {
                                            fileData.append("Suppression du client instable : "+node.getAttributeValue("name").toString()+"\n");
                                        } catch (IOException e1) {
                                            e1.printStackTrace();
                                        }
                                    }

                                   for(INode client : allClientsToStabilityPoint){

                                       if(!currentUnstableClientList.contains(client) && !currentStableClientList.contains(client)){

                                           currentStableClientList.add(client);
                                           if(!oldStableClientList.contains(client)){

                                               try {
                                                   fileData.append("\tAjout du client stable : "+client.getAttributeValue("name").toString()+"\n");
                                                   finalStableClientList.add(client);
                                               } catch (IOException e1) {
                                                   e1.printStackTrace();
                                               }
                                           }
                                           else{
                                               oldStableClientList.remove(client);

                                           }
                                       }
                                   }

                                    for(INode client : oldStableClientList){
                                        try {
                                            fileData.append("\tSuppression du client stable : "+client.getAttributeValue("name").toString()+"\n");
                                        } catch (IOException e1) {
                                            e1.printStackTrace();
                                        }
                                    }



                                    oldUnstableClientList.clear();
                                    for(INode nd : currentUnstableClientList){

                                        oldUnstableClientList.add(nd);
                                    }

                                    oldStableClientList.clear();
                                    for(INode nd : currentStableClientList){

                                        oldStableClientList.add(nd);
                                    }
                                }

                            }
                        }
                    }
                }

                try {

                    fileEvolution.write(":LISTE DES CLIENTS STABLES:\n");
                    for(INode node : finalStableClientList){
                        fileEvolution.append(node.getAttributeValue("name").toString()+"\n");
                    }
                    fileEvolution.write(":LISTE DES CLIENTS INSTABLES:\n");
                    for(INode node : finalUnstableClientList){
                        fileEvolution.append(node.getAttributeValue("name").toString()+"\n");
                    }
                } catch (IOException e1) {
                    e1.printStackTrace();
                }

                try {
                    fileData.close();
                    fileEvolution.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }


        }





        else if (cmdName.equals("DataForSpecificStabilityPoint")) {


            //get all stability point in the current project
            List<INode> allStabilityPoints = new ArrayList<INode>();
            for (RevisionTime rev : codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions()) {
                ICluster cl = null;
                IGraph softwareGraph = codeHistoryCtrl.getGraph(rev);
                if (softwareGraph.getClusters().size() > 0) {
                    for (ICluster cluster : softwareGraph.getClusters()) {
                        if(!allStabilityPoints.contains(cluster.getDefinedForNode()))
                        {
                            allStabilityPoints.add(cluster.getDefinedForNode());
                        }

                    }

                }
            }
            System.out.println("size="+allStabilityPoints.size());
           for(INode nodeStability : allStabilityPoints){

            String stabilityPoint =   nodeStability.getAttributeValue("name").toString() ;
               System.out.println(nodeStability.getAttributeValue("name").toString());

            IGraph softwareGraph;
            int nbClientStable = 0;
            int nbClientInstable = 0;
            List<INode> tabInsideNodes = new ArrayList<INode>();
            List<INode> tabAllClient = new ArrayList<INode>();
            List<INode> tabUnstableClient = new ArrayList<INode>();
            List<INode> tabStableClient = new ArrayList<INode>();
            List<INode>   tabNtoFile = new ArrayList<INode>() ;
               List<INode>   tabStoFile = new ArrayList<INode>() ;
               List<INode>   tabUtoFile = new ArrayList<INode>() ;
               FileWriter fileEvolution = null;
               try {
                   file  = new FileWriter("C:/Users/Elyes/stabilityPoint/stabilitypoints/"+stabilityPoint.substring(stabilityPoint.indexOf(":")+1,stabilityPoint.length()-1)+".txt", true);
                    fileEvolution = new FileWriter("C:/Users/Elyes/stabilityPoint/evolution/"+stabilityPoint.substring(stabilityPoint.indexOf(":")+1,stabilityPoint.length()-1)+"_Evolution.txt", true);
                   fileEvolution.write("evolution du point de stabilité "+stabilityPoint+"\n");
               } catch (IOException e1) {
                   e1.printStackTrace();
               }


               for (RevisionTime rev : codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions()) {
                ICluster cl = null;
                softwareGraph = codeHistoryCtrl.getGraph(rev);
                if (softwareGraph.getClusters().size() > 0) {
                    for (ICluster cluster : softwareGraph.getClusters()) {
                        if (cluster.getDefinedForNode().getAttributeValue("name").equals(stabilityPoint) && cluster.getNodes().size() >= 0) {
                            cl = cluster;
                            //System.out.println("----------------Revision " + rev.getRevision().intValue() + "----------------");
                            //System.out.println("Liste des implémentations du point de stabilité " + stabilityPoint);
                            try {
                                fileEvolution.append("----------------Revision " + rev.getRevision().intValue() + "----------------\n");
                                fileEvolution.append("Liste des implémentations du point de stabilité " + stabilityPoint+"\n");
                            } catch (IOException e1) {
                                e1.printStackTrace();
                            }


                            tabInsideNodes = cluster.getNodes();
                            for (INode nd : tabInsideNodes) {
                                System.out.println("\t" + nd.getAttributeValue("name"));
                                try {
                                    fileEvolution.append("\t" + nd.getAttributeValue("name")+"\n");
                                    tabNtoFile.add(nd);
                                } catch (IOException e1) {
                                    e1.printStackTrace();
                                }
                            }
                            for (IEdge edge : cluster.getDefinedForNode().getIncomingEdges()) {
                                if (edge.getInNode() != cluster.getDefinedForNode() && !tabInsideNodes.contains(edge.getInNode())) {

                                    tabAllClient.add(edge.getInNode());

                                }
                            }
                            //System.out.println("Liste des clients instables du point de stabilité "+stabilityPoint);
                            try {
                                fileEvolution.append("Liste des clients instables du point de stabilité "+stabilityPoint+"\n");
                            } catch (IOException e1) {
                                e1.printStackTrace();
                            }
                            for (INode client : tabAllClient) {

                                for (IEdge edge : client.getOutgoingEdges()) {
                                    if (!tabUnstableClient.contains(client) && tabInsideNodes.contains(edge.getOutNode()))
                                        tabUnstableClient.add(client);
                                }

                            }
                            for (INode node : tabUnstableClient) {
                                //System.out.print("\tLa classe instable " + node.getAttributeValue("name"));
                                try {
                                    fileEvolution.append("\tLa classe instable " + node.getAttributeValue("name"));
                                    tabUtoFile.add(node);
                                } catch (IOException e1) {
                                    e1.printStackTrace();
                                }
                                for (IEdge edge : node.getOutgoingEdges()) {
                                    if (tabInsideNodes.contains(edge.getOutNode())) {
                                        //System.out.println("\t invoque " + edge.getOutNode().getAttributeValue("name"));
                                        try {
                                            fileEvolution.append("\t invoque " + edge.getOutNode().getAttributeValue("name")+"\n");
                                        } catch (IOException e1) {
                                            e1.printStackTrace();
                                        }
                                    }
                                }
                            }

                            //System.out.println("Liste des clients stables du point de stabilité "+stabilityPoint);
                            try {
                                fileEvolution.append("Liste des clients stables du point de stabilité "+stabilityPoint+"\n");
                            } catch (IOException e1) {
                                e1.printStackTrace();
                            }
                            for (INode node : tabAllClient) {
                                if (!tabUnstableClient.contains(node)) {
                                    tabStableClient.add(node);
                                    System.out.println("\t" + node.getAttributeValue("name"));
                                    try {
                                        tabStoFile.add(node);
                                        fileEvolution.append("\t" + node.getAttributeValue("name")+"\n");
                                    } catch (IOException e1) {
                                        e1.printStackTrace();
                                    }
                                }

                            }


                        }
                    }
                    if (cl != null && cl.getNodes().size() >= 0) break;
                }

            }


            for (RevisionTime rev : codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions()) {
                //System.out.println("----------------Revision " + rev.getRevision().intValue() + "----------------");
                try {
                    fileEvolution.append("----------------Revision " + rev.getRevision().intValue() + "----------------"+"\n");
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
                softwareGraph = codeHistoryCtrl.getGraph(rev);
                if (softwareGraph.getClusters().size() > 0) {
                    for (ICluster cluster : softwareGraph.getClusters()) {
                        if (cluster.getDefinedForNode().getAttributeValue("name").equals(stabilityPoint)) {

                            if (tabInsideNodes.size() < cluster.getNodes().size()) {

                                for (INode node : cluster.getNodes()) {
                                    if (!tabInsideNodes.contains(node)) {
                                        //System.out.println("\t" + node.getAttributeValue("name") + " a été ajoutée à la liste d'implémentations");
                                        try {
                                            fileEvolution.append("\t" + node.getAttributeValue("name") + " a été ajoutée à la liste d'implémentations" + "\n");
                                        } catch (IOException e1) {
                                            e1.printStackTrace();
                                        }
                                        tabNtoFile.add(node);
                                    }
                                }
                                tabInsideNodes.clear();
                                tabInsideNodes = cluster.getNodes();
                            } else if (tabInsideNodes.size() > cluster.getNodes().size()) {

                                for (INode node : tabInsideNodes) {

                                    if (!cluster.getNodes().contains(node)) {

                                        try {
                                            fileEvolution.append("\t" + node.getAttributeValue("name") + " a été supprimée de la liste d'implémentations"+"\n");
                                        } catch (IOException e1) {
                                            e1.printStackTrace();
                                        }
                                        //System.out.println("\t" + node.getAttributeValue("name") + " a été supprimée de la liste d'implémentations");
                                    }
                                }
                                tabInsideNodes.clear();
                                tabInsideNodes = cluster.getNodes();
                            }

                            tabAllClient.clear();
                            for (IEdge edge : cluster.getDefinedForNode().getIncomingEdges()) {
                                if (edge.getInNode() != cluster.getDefinedForNode() && !tabInsideNodes.contains(edge.getInNode())) {

                                    tabAllClient.add(edge.getInNode());

                                }
                            }

                            List<INode> tabUnstableClient1 = new ArrayList<INode>();
                            for (INode client : tabAllClient) {

                                for (IEdge edge : client.getOutgoingEdges()) {
                                    if (!tabUnstableClient1.contains(client) && tabInsideNodes.contains(edge.getOutNode()))
                                        tabUnstableClient1.add(client);
                                }

                            }
                            if (tabUnstableClient1.size() > tabUnstableClient.size()) {
                                for (INode node : tabUnstableClient1) {
                                    if (!tabUnstableClient.contains(node)) {
                                        // System.out.print("\tAjout du client instable " + node.getAttributeValue("name"));
                                        try {
                                            fileEvolution.append("\tAjout du client instable " + node.getAttributeValue("name"));
                                        } catch (IOException e1) {
                                            e1.printStackTrace();
                                        }
                                        tabUtoFile.add(node);
                                        for (IEdge edge : node.getOutgoingEdges()) {
                                            if (tabInsideNodes.contains(edge.getOutNode())) {
                                                //System.out.println("\tinvoque " + edge.getOutNode().getAttributeValue("name"));
                                                try {
                                                    fileEvolution.append("\tinvoque " + edge.getOutNode().getAttributeValue("name")+"\n");
                                                } catch (IOException e1) {
                                                    e1.printStackTrace();
                                                }
                                            }
                                        }
                                    }
                                }
                            } else if (tabUnstableClient1.size() < tabUnstableClient.size()) {
                                for (INode node : tabUnstableClient) {
                                    if (!tabUnstableClient1.contains(node)) {
                                        //System.out.println("\tsupression du client instable " + node.getAttributeValue("name"));
                                        try {
                                            fileEvolution.append("\tsupression du client instable " + node.getAttributeValue("name")+"\n");
                                        } catch (IOException e1) {
                                            e1.printStackTrace();
                                        }
                                    }
                                }

                            }

                            tabUnstableClient = tabUnstableClient1;

                            //client stable traitement
                            List<INode> tabStableClient1 = new ArrayList<INode>();
                            for (INode node : tabAllClient) {

                                if (!tabUnstableClient.contains(node)) {
                                    tabStableClient1.add(node);
                                }
                            }

                            if (tabStableClient1.size() > tabStableClient.size()) {
                                for (INode node : tabStableClient1) {
                                    if (!tabStableClient.contains(node)) {
                                        //System.out.println("\t Ajout du client stable " + node.getAttributeValue("name"));
                                        try {
                                            fileEvolution.append("\t Ajout du client stable " + node.getAttributeValue("name") + "\n");
                                        } catch (IOException e1) {
                                            e1.printStackTrace();
                                        }
                                        tabStoFile.add(node);
                                    }
                                }
                            } else if (tabStableClient1.size() < tabStableClient.size()) {
                                for (INode node : tabStableClient) {
                                    if (!tabStableClient1.contains(node)) {
                                        //System.out.println("\t Suppression du client stable " + node.getAttributeValue("name"));
                                        try {
                                            fileEvolution.append("\t Suppression du client stable " + node.getAttributeValue("name")+"\n");
                                        } catch (IOException e1) {
                                            e1.printStackTrace();
                                        }
                                    }
                                }
                            }
                            tabStableClient = tabStableClient1;

                        }
                    }
                }
            }
               try {
                   file.write(stabilityPoint+"\n"+":liste des implementations"+"\n");
                   for( INode node : tabNtoFile)
                   {
                       file.append(node.getAttributeValue("name").toString()+"\n");
                   }
                   file.append(":liste des clients instables\n");
                   for( INode node : tabUtoFile)
                   {
                       file.append(node.getAttributeValue("name").toString()+"\n");
                   }
                   file.append(":liste des clients stables\n");
                   for( INode node : tabStoFile)
                   {
                       file.append(node.getAttributeValue("name").toString()+"\n");
                   }


               } catch (IOException e1) {
                   e1.printStackTrace();
               }

               try {
                   fileEvolution.close();
                   file.close();
               } catch (IOException e1) {
                   e1.printStackTrace();
               }

           }
            System.out.println("----------------------------------------------------------------------------------------------");

        }

        else if (cmdName.equals("DisplayAllData")){
            //creation d'un fichier csv qui contient toutes les données liées a chaque point de stabilité => all-data

            int nbrRevision = codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions().size();
            RevisionTime revision =  codeHistoryCtrl.getCodeHistory().getTimeslices().get(nbrRevision-1);
            IGraph softwareGraphAtRevision = codeHistoryCtrl.getGraph(revision);
            ArrayList<DataStabilityPoint> List = new ArrayList<DataStabilityPoint>();

            String Header_file = "Revision,";
            for(ICluster cluster : softwareGraphAtRevision.getClusters()){
                Header_file += cluster.getDefinedForNode().getAttributeValue("name")+",,,,,";
                List.add(new DataStabilityPoint(cluster.getDefinedForNode(), nbrRevision-1));
            }
            try {
                file  = new FileWriter("C:/Users/Elyes/data.csv", true);
                file.write(Header_file);
                file.append("\n");

                for(ICluster cluster : softwareGraphAtRevision.getClusters()){
                    file.append(",N,S,U,Us,Unew");
                }
                file.append("\n");


            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }

            List<INode> listNodesInZone ;
            ArrayList<INode> listClientToStableNode = new ArrayList<INode>();
            ArrayList<INode> TableOfUnprotectedClient = new ArrayList<INode>();
            ArrayList<INode> TableOfUnprotectedNew = new ArrayList<INode>();
            int nbRev = 0 ;
            INode StableNode;
            IGraph softwareGraph;


            for(RevisionTime rev : codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions() ){

                softwareGraph = codeHistoryCtrl.getGraph(rev);
                if(softwareGraph.getClusters().size()>0){

                    for(ICluster cluster : softwareGraph.getClusters()){
                        StableNode = cluster.getDefinedForNode();
                        listNodesInZone = cluster.getNodes();
                        listNodesInZone.remove(StableNode);
                        for(IEdge edgeToStableNode  : StableNode.getIncomingEdges()){

                            if(edgeToStableNode.getInNode()!=StableNode && ! listNodesInZone.contains(edgeToStableNode.getInNode())) //parfois le point de stabilité a un selfedge
                            {
                                listClientToStableNode.add(edgeToStableNode.getInNode());
                            }
                        }


                        for(INode client : listClientToStableNode){

                            for(IEdge edge : client.getOutgoingEdges())
                            {
                                if( ! TableOfUnprotectedClient.contains(client)  && listNodesInZone.contains(edge.getOutNode()))
                                    TableOfUnprotectedClient.add(client);
                            }
                        }

                        for(INode client : TableOfUnprotectedClient){

                            for(IEdge edge : client.getOutgoingEdges())
                            {
                                if( !TableOfUnprotectedNew.contains(client) && edge.includesEdgeType(JavaParserUtil.EDGE_TYPE_IMPORT_NEW_DEP) && listNodesInZone.contains(edge.getOutNode())  ){
                                    TableOfUnprotectedNew.add(client);
                                }

                            }
                        }

                        for(DataStabilityPoint data : List){

                            if(data.getStableNode().equals(StableNode)){
                                data.addTableN(listNodesInZone.size(), nbRev);
                                data.addTableS((listClientToStableNode.size()-TableOfUnprotectedClient.size()), nbRev);
                                data.addTableU(TableOfUnprotectedClient.size(), nbRev);
                                data.addTableUnew(TableOfUnprotectedNew.size(), nbRev);
                                data.addTableUs((TableOfUnprotectedClient.size()-TableOfUnprotectedNew.size()), nbRev);
                            }
                        }

                        //stocker les données dans arraylist
	        				/*System.out.println("stable node "+StableNode.getAttributeValue("name"));
	        				System.out.println("N = "+listNodesInZone.size());
	        				System.out.println("U = "+TableOfUnprotectedClient.size());
	        				System.out.println("S = "+(listClientToStableNode.size()-TableOfUnprotectedClient.size()));
	        				System.out.println("Unew = "+TableOfUnprotectedNew.size());
	        				System.out.println("Us = "+(TableOfUnprotectedClient.size()-TableOfUnprotectedNew.size()));*/

                        System.out.println("***************************************************");
                        listNodesInZone.clear();
                        TableOfUnprotectedClient.clear();
                        listClientToStableNode.clear();
                        TableOfUnprotectedNew.clear();

                    }
                    nbRev++;
                }

            }
            //remplir le fichier par les données
            nbRev = 0 ;
            for(RevisionTime rev : codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions() ){

                softwareGraph = codeHistoryCtrl.getGraph(rev);
                if(softwareGraph.getClusters().size()>0){

                    try {
                        RepositoryChange repositoryChange = codeHistoryCtrl.getCodeHistory().getRepositoryChange(rev);


                        file.append("rev "+rev.getRevision().intValue()+" [ "+repositoryChange.getLogMessage().replaceAll("[,]"," ").replaceAll("[\n]","")+" ]"+",");

                        for(DataStabilityPoint data : List){

                            //file.append(","+data.getValueTableN(nbRev)+","+data.getValueTableS(nbRev)+","+data.getValueTableU(nbRev)+","+data.getValueTableUs(nbRev)+","+data.getValueTableUnew(nbRev));
                            if(data.getValueTableN(nbRev)== -1)
                            {	file.append(",,,,,");

                            }
                            else
                            {
                                file.append(String.valueOf(data.getValueTableN(nbRev)));
                                file.append(","+data.getValueTableS(nbRev));
                                file.append(","+data.getValueTableU(nbRev));
                                file.append(","+data.getValueTableUs(nbRev));
                                file.append(","+data.getValueTableUnew(nbRev)+",");

                            }

                        }
                        file.append("\n");

                    } catch (IOException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    }
                    nbRev++;
                }
            }
            try {
                file.close();
            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }

        }

        else if (cmdName.equals("NewJsonFile")) {

            //Generate new Json file for new SVN
            String targetFileName = "C:/Users/Elyes/IdeaProjects/softvis-variability/data/newJsonfile-export.json";

            IGraphHistoryUtil.graphHistoryToJson(
                    codeHistoryCtrl,
                    codeHistoryCtrl.getCodeHistory()
                    , targetFileName
            );

            for(RevisionTime rev : codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions())
            {

                if(rev.getRevision()==45)
                {
                    IGraph graph = codeHistoryCtrl.getGraph(rev);
                    for(ICluster cluster : graph.getClusters())
                    {
                        if(cluster.getDefinedForNode().getAttributeValue("name").equals("CH.ifa.draw.contrib:Desktop:"))
                        {

                           GraphNodeCollection graph1 =  cluster.getDefinedForNode().getAllChildren();
                            for (INode nd : graph1.getNodes()){

                                System.out.println(nd.getAttributeValue("name"));
                            }

                        }
                    }
                }
            }
            System.out.println("-------------------------------------------------------------------------------------");
            for(RevisionTime rev : codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions())
            {

                if(rev.getRevision()==44)
                {
                    IGraph graph = codeHistoryCtrl.getGraph(rev);
                    for(INode nd : graph.getNodes())
                    {

                        if(nd!=null) {
                            if (nd.getAttributeValue("name").equals("CH.ifa.draw.contrib:MDIDesktopPane:")) {
                                System.out.println("exist");
                                GraphNodeCollection graph1 = nd.getAllChildren();
                                for (INode nod : graph1.getNodes()) {

                                    System.out.println(nod.getAttributeValue("name"));
                                }
                            }
                        }


                    }
                }
            }
            System.out.println("-------------------------------------------------------------------------------------");



        }

        else if (cmdName.equals("LineDrawingTest")) {


            //TODO Insérer le test case reproducible ici


            GraphChangeHistory graphChangeHistory = codeHistoryCtrl.getCodeHistory();


            for (RevisionTime t : graphChangeHistory.getTimeslices().getAllRevisions()) {


                GraphChangeList graphChangeList = graphChangeHistory.getGraphChange(t);

                //Exemple : le nouveau cluster CommandChoice est ajoutÈ ‡ la rÈvision 2 jusqu'‡ la rÈvision 7.
                //Aussi, ‡ la rÈvision 7, il est modifiÈ (un second noeud y est ajoutÈ)
                //‡ la rÈvision 22, le cluster est supprimÈ

                //Pour ce faire, nous crÈons les clusters ‡ chaque rÈvision (pour les afficher maintenant)
                //Nous exportons deux ÈvÈnements : crÈation du cluster ‡ la rÈvision 2 et modification de ce cluster ‡ la rÈvision 7.

                //Ajouts de clusters
                if (t.getRevision() >= 2) {

                    //CrÈation du cluster pour affichage dans la vue courante
                    IGraph graphAtT = codeHistoryCtrl.getGraph(t);
                    INode keyNode = graphAtT.findNodeAttributeValueExact("CH.ifa.draw.util:CommandChoice:", "name");
                    INode insideNode1 = graphAtT.findNodeAttributeValueExact("CH.ifa.draw.util:Command:", "name");

                    ICluster cmdChoiceCluster = graphAtT.addCluster( keyNode, new NodeCollection(graphAtT.getGraphMapper(),insideNode1), null);

                    //Exporte l'ÈvÈnement 'nouveau cluster ajoutÈ ‡ la rÈvision 2'
                    if (t.getRevision() == 2) {
                        cmdChoiceClusterId = cmdChoiceCluster.getId();
                        GraphChange addClusterGraphChange = createGraphChangeAddCluster(cmdChoiceClusterId, cmdChoiceCluster);
                        graphChangeList.add ( addClusterGraphChange );
                    }

                }

                //Modifications de clusters
                if (t.getRevision() >= 42) {

                    IGraph graphAtT = codeHistoryCtrl.getGraph(t);

                    //Get cluster to be modified
                    INode keyNode = graphAtT.findNodeAttributeValueExact("CH.ifa.draw.util:CommandChoice:", "name");
                    ICluster modifiedCmdChoiceCluster = graphAtT.getClustersDefinedForNode( keyNode ).iterator().next();

                    //Add a new node inside that cluster
                    INode insideNode2 = graphAtT.findNodeAttributeValueExact("CH.ifa.draw.standard:AlignCommand:", "name");
                    modifiedCmdChoiceCluster.getNodes().add( insideNode2 );

                    if (t.getRevision() == 42) {

                        //Generate event : 'modify cluster' (which now contains a new element) at revision 7
                        GraphChange modClusterGraphChange = createGraphChangeModCluster(cmdChoiceClusterId, modifiedCmdChoiceCluster);
                        graphChangeList.add ( modClusterGraphChange );

                    }

                }
                if (t.getRevision() >= 43) {

                    IGraph graphAtT = codeHistoryCtrl.getGraph(t);

                    //Get cluster to be modified
                    INode keyNode = graphAtT.findNodeAttributeValueExact("CH.ifa.draw.util:CommandChoice:", "name");
                    ICluster modifiedCmdChoiceCluster = graphAtT.getClustersDefinedForNode( keyNode ).iterator().next();

                    //Add a new node inside that cluster
                    INode insideNode2 = graphAtT.findNodeAttributeValueExact("CH.ifa.draw.figures:GroupCommand:", "name");
                    modifiedCmdChoiceCluster.getNodes().add( insideNode2 );
                    INode insideNode3 = graphAtT.findNodeAttributeValueExact("CH.ifa.draw.standard:AbstractCommand:", "name");
                    modifiedCmdChoiceCluster.getNodes().add( insideNode3 );

                    if (t.getRevision() == 43) {

                        //Generate event : 'modify cluster' (which now contains a new element) at revision 7
                        GraphChange modClusterGraphChange = createGraphChangeModCluster(cmdChoiceClusterId, modifiedCmdChoiceCluster);
                        graphChangeList.add ( modClusterGraphChange );

                    }

                }
                if (t.getRevision() >= 45) {

                    IGraph graphAtT = codeHistoryCtrl.getGraph(t);

                    //Get cluster to be modified
                    INode keyNode = graphAtT.findNodeAttributeValueExact("CH.ifa.draw.util:CommandChoice:", "name");
                    ICluster modifiedCmdChoiceCluster = graphAtT.getClustersDefinedForNode( keyNode ).iterator().next();

                    //Add a new node inside that cluster
                    INode insideNode2 = graphAtT.findNodeAttributeValueExact("CH.ifa.draw.standard:ToggleGridCommand:", "name");
                    modifiedCmdChoiceCluster.getNodes().add( insideNode2 );


                    if (t.getRevision() == 45) {

                        //Generate event : 'modify cluster' (which now contains a new element) at revision 7
                        GraphChange modClusterGraphChange = createGraphChangeModCluster(cmdChoiceClusterId, modifiedCmdChoiceCluster);
                        graphChangeList.add ( modClusterGraphChange );

                    }

                }



            }



            String targetFileName = "data/jhotdraw6-test.json";

            IGraphHistoryUtil.graphHistoryToJson(
                    codeHistoryCtrl,
                    codeHistoryCtrl.getCodeHistory()
                    , targetFileName
            );


        }


        Logger.debug("End - Command " + cmdName);

    }

    private GraphChange createGraphChangeAddCluster(Integer clusterId, ICluster cluster) {
        GraphChange addClusterGraphChange = null;

        Integer clusterDefinedForNodeId = (Integer) cluster.getDefinedForNode().getAttribute("nodeId");

        String clusterDefinedForNodeKey = (String) cluster.getDefinedForNode().getAttribute("name", "");
        String clusterNodesIncluded = ListUtil.listToString(cluster.getNodes(), new ListUtil.ObjectToString() {
            @Override
            public String itemToString(Object item) {
                return "" + ((INode) item).getAttribute("nodeId");
            }
        });

        Map<String,String> mapMetrics = new HashMap<String, String>();

        addClusterGraphChange = new AddClusterGenericGraphChange(clusterId, clusterDefinedForNodeId, clusterDefinedForNodeKey,clusterNodesIncluded, mapMetrics);
        return addClusterGraphChange;
    }


    private GraphChange createGraphChangeModCluster(Integer clusterId, ICluster cluster) {
        GraphChange graphChange = null;

        Integer clusterDefinedForNodeId = (Integer) cluster.getDefinedForNode().getAttribute("nodeId");

        String clusterDefinedForNodeKey = (String) cluster.getDefinedForNode().getAttribute("name", "");
        String clusterNodesIncluded = ListUtil.listToString(cluster.getNodes(), new ListUtil.ObjectToString() {
            @Override
            public String itemToString(Object item) {
                return "" + ((INode) item).getAttribute("nodeId");
            }
        });

        Map<String,String> mapMetrics = new HashMap<String, String>();

        graphChange = new ModClusterGenericGraphChange(clusterId, clusterDefinedForNodeId, clusterDefinedForNodeKey,clusterNodesIncluded, mapMetrics);
        return graphChange;
    }



    private GraphChange createGraphChangeDelCluster(Integer clusterId, ICluster cluster) {
        GraphChange graphChange = null;

        Integer clusterDefinedForNodeId = (Integer) cluster.getDefinedForNode().getAttribute("nodeId");

        String clusterDefinedForNodeKey = (String) cluster.getDefinedForNode().getAttribute("name", "");

        graphChange = new RemClusterGenericGraphChange(clusterId, clusterDefinedForNodeId, clusterDefinedForNodeKey);
        return graphChange;
    }

    private class UnprotectedClient {

        private INode Node ;
        private ArrayList<IEdge> TableEdges ;

        public UnprotectedClient(INode node){

            Node = node ;
            TableEdges = new ArrayList<IEdge>();
        }
        public INode getClient(){return Node;}
        public ArrayList<IEdge> getTableEdges(){return TableEdges;};
        public void AddEdge(IEdge edge)
        {
            TableEdges.add(edge);
        }
        public void RemoveEdge(IEdge edge){
            TableEdges.remove(edge);
        }
    }

    private class DataStabilityPoint {

        private INode StabilityNode;
        private int[] tableN;
        private int[] tableS;
        private int[] tableU;
        private int[] tableUnew;
        private int[] tableUs;

        public DataStabilityPoint(INode node,int nbrRev){

            StabilityNode = node ;
            tableN = new int[nbrRev];
            tableS = new int[nbrRev];
            tableU = new int[nbrRev];
            tableUnew = new int[nbrRev];
            tableUs = new int[nbrRev];

            for(int i=0;i<nbrRev;i++){

                tableN[i]=-1;
                tableS[i]=-1;
                tableU[i]=-1;
                tableUnew[i]=-1;
                tableUs[i]=-1;
            }

        }

        public INode getStableNode(){return StabilityNode;}
        public void addTableN(int value,int index){tableN[index]=value;}
        public void addTableS(int value,int index){tableS[index]=value;}
        public void addTableU(int value,int index){tableU[index]=value;}
        public void addTableUnew(int value,int index){tableUnew[index]=value;}
        public void addTableUs(int value,int index){tableUs[index]=value;}

        public int getValueTableN(int index){return tableN[index];}
        public int getValueTableS(int index){return tableS[index];}
        public int getValueTableU(int index){return tableU[index];}
        public int getValueTableUnew(int index){return tableUnew[index];}
        public int getValueTableUs(int index){return tableUs[index];}
    }


}