package softvis.ui;

/**
 * Created by seb on 2013-12-08.
 */

import infoHidingVisu.app.Constants;
import infoHidingVisu.codehistory.CodeHistoryController;
import infoHidingVisu.data.ClusterImpl;
import infoHidingVisu.data.GraphImpl;
import infoHidingVisu.data.VilogToIGraphVisitor;
import infoHidingVisu.graphevolution.RevisionTime;
import infoHidingVisu.graphevolution.RevisionTimeSet;
import infoHidingVisu.shape.ClusterVisualShape;
import infoHidingVisu.shape.TimeSliceShape;
import infoHidingVisu.ui.UserInteractions;
import infoHidingVisu.ui.UserSettings;
import infoHidingVisu.ui.UserSettingsListener;
import infoHidingVisu.util.IGraphLayoutHistory;
import infoHidingVisu.util.JavaGraphUtil;
import infoHidingVisu.visu.ControllerEvent;
import infoHidingVisu.visu.ControllerListener;
import infoHidingVisu.visu.VisuFactory;
import infoHidingVisu.visu.VisuTimelineLayout;
import net.miginfocom.swing.MigLayout;
import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;
import org.jdesktop.swingx.renderer.DefaultListRenderer;
import softvis.views.SoftVisuOverviewController;
import vilog.change.repository.cache.RepositoryCacheDatabaseFactory;
import vilog.common.data.GraphNode;
import vilog.common.data.ICluster;
import vilog.common.data.IGraph;
import vilog.common.data.INode;
import vilog.common.utils.IProgressMonitor;
import vilog.common.utils.Logger;
import vilog.common.utils.Timer;
import vilog.modeles.SolutionInfos;
import vilog.modeles.SolutionsInfosCollection;
import vilog.modeles.SolutionsInfosCollectionFactory;
import visu.core.BasicGLComponent;
import visu.core.GLDrawer;
import visu.core.ShapeEventListener;
import visu.core.VisualShape;

import javax.media.opengl.GLCapabilities;
import javax.media.opengl.GLProfile;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.util.ArrayList;


/*
 * Main app window.
 */
public class SoftVisMainWindow implements ControllerListener, IProgressMonitor {

    public static final String applicationName = "Variability Explorer";
    private JFrame frame;
    private JPanel panControls;
    private BasicGLComponent canvasMain;
    private BasicGLComponent canvasBottom;
    private CodeHistoryController codeHistoryCtrl = new CodeHistoryController();
    private JTextArea txtInfos;
    private JScrollPane txtInfosScrollPane;
    private GLDrawer visuMain;
    private GLDrawer visuBottom;
    private SolutionsInfosCollection solInfosCol;
    private ProgressMonitor progress;
    private Double lastShownProgressRatio = null;
    private ICluster nullInstance;
    private DefaultComboBoxModel instanceModel;
    private JComboBox cboInstanceSelect;


    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    SoftVisMainWindow  window = new SoftVisMainWindow();

                    window.frame.setVisible(true);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public SoftVisMainWindow() {



        KeyboardFocusManager manager = KeyboardFocusManager.getCurrentKeyboardFocusManager();
        manager.addKeyEventDispatcher(new MyDispatcher());

        loadSettingsDefaults();

        solInfosCol = SolutionsInfosCollectionFactory.getInstance().creerSolutionInfos();

        this.codeHistoryCtrl.setProgressMonitor(this);

        loadData();
        initialize();

    }

    private void loadData() {

        // save browsed svn transactions
        Timer.getInstance().start();
        RepositoryCacheDatabaseFactory.getInstance().load();
        Timer.getInstance().printElapsed(getClass(), "SVN cache Data loaded.");

    }

    /**
     * Initialize the contents of the frame.
     */


    private void initialize() {

        frame = new JFrame(applicationName);
        frame.setResizable(true);
        frame.setBounds(new Rectangle(0, 0, Constants.INITIAL_WINDOW_WIDTH, Constants.INITIAL_WINDOW_HEIGHT));
        //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        JMenuBar menuBar = new JMenuBar();
        frame.setJMenuBar(menuBar);

        frame.setVisible(false);

        //File menu
        JMenu mnFile = new JMenu("File");
        menuBar.add(mnFile);

        JMenuItem mntmExit = new JMenuItem("Exit");
        mntmExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {

                Logger.getInstance().endFileOutput();
                // if (JOptionPane.showConfirmDialog(frame, "Really quit ? ",
                // "Exit", JOptionPane.YES_NO_OPTION,
                // JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION) {
                System.exit(0);
                // }
            }
        });
        mnFile.add(mntmExit);




        //Tools menu
        ActionListener menuItemController = new MenuItemController(codeHistoryCtrl);

        JMenu mnTools = new JMenu("Tools");
        menuBar.add(mnTools);

        JMenuItem mntmChangeHistory = new JMenuItem("Display Change History");
        JMenuItem mntmStabilityPointsList = new JMenuItem("Display Stability Points");
        JMenuItem exportDataMenu = new JMenuItem("Export Data Test");
        JMenuItem lineDrawingTest = new JMenuItem("Line Drawing Test");
        JMenuItem newJsonfile = new JMenuItem("New Json File");
        JMenuItem generateJson = new JMenuItem("Generate Json");
        JMenuItem DisplayAllData = new JMenuItem("Generate All measures");
        JMenuItem DisplayPremInformation = new JMenuItem("Display preliminary informations");
        JMenuItem  DataForSpecificStabilityPoint = new JMenuItem("Data for specific SP");
        JMenuItem  hypothesisAnalyse = new JMenuItem("Hypothesis analyse");
        JMenuItem  generateAllClients = new JMenuItem("Generate all clients");

        mntmChangeHistory.setActionCommand("DisplayChangeHistory");
        mntmStabilityPointsList.setActionCommand("DisplayStabilityPointsList");
        exportDataMenu.setActionCommand("ExportDataTest");
        lineDrawingTest.setActionCommand("LineDrawingTest");
        newJsonfile.setActionCommand("NewJsonFile");
        generateJson.setActionCommand("GenerateJson");
        DisplayAllData.setActionCommand("DisplayAllData");
        DisplayPremInformation.setActionCommand("DisplayPremInformation");
        DataForSpecificStabilityPoint.setActionCommand("DataForSpecificStabilityPoint");
        hypothesisAnalyse.setActionCommand("Hypothesis");
        generateAllClients.setActionCommand("generateAllClients");

        mntmChangeHistory.addActionListener(menuItemController);
        mntmStabilityPointsList.addActionListener(menuItemController);
        exportDataMenu.addActionListener(menuItemController);
        lineDrawingTest.addActionListener(menuItemController);
        newJsonfile.addActionListener(menuItemController);
        generateJson.addActionListener(menuItemController);
        DisplayAllData.addActionListener(menuItemController);
        DisplayPremInformation.addActionListener(menuItemController);
        DataForSpecificStabilityPoint.addActionListener(menuItemController);
        hypothesisAnalyse.addActionListener(menuItemController);
        generateAllClients.addActionListener(menuItemController);

        mnTools.add(mntmChangeHistory);
        //mnTools.add(mntmStabilityPointsList);
        //mnTools.add(exportDataMenu);
        //mnTools.add(lineDrawingTest);
        //mnTools.add(newJsonfile);
        mnTools.add(generateJson);
        mnTools.add(DisplayAllData);
        mnTools.add(DisplayPremInformation);
        mnTools.add(DataForSpecificStabilityPoint);
        mnTools.add(generateAllClients);

        //---



        if (UserInteractions.getInstance().isExperimentMode())
            mntmExit.setEnabled(false);


        JMenu mnAbout = new JMenu("Help");
        menuBar.add(mnAbout);

        JMenuItem mntmAbout = new JMenuItem("About");
        mntmAbout.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                JOptionPane.showMessageDialog(frame, "" + applicationName + "\n" + "Tous droits r�serv�s. 2014",
                        "About", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        mnAbout.add(mntmAbout);


        if (UserInteractions.getInstance().isExperimentMode())
            mnAbout.setEnabled(false);


        if (UserInteractions.getInstance().isExperimentMode()) {
            JMenu mnExpMode = new JMenu("(Experiment Mode)");
            mnExpMode.setEnabled(false);
            menuBar.add(mnExpMode);
        }

        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                Logger.getInstance().log(getClass(), "Window closing...",3);

                Logger.getInstance().endFileOutput();
            }
        });

        frame.getContentPane().setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.X_AXIS));

        JSplitPane hControlSplitPane = new JSplitPane();
        hControlSplitPane.setEnabled(true);

        hControlSplitPane.setResizeWeight(0.9);
        hControlSplitPane.setOneTouchExpandable(true);
        hControlSplitPane.setContinuousLayout(true);
        frame.getContentPane().add(hControlSplitPane);

        JSplitPane vViewSplitPane = new JSplitPane();
        vViewSplitPane.setEnabled(true);
        vViewSplitPane.setOrientation(JSplitPane.VERTICAL_SPLIT);

        canvasBottom = createJOGLCanvas(Constants.CANVAS_BOTTOM_WIDTH, Constants.CANVAS_BOTTOM_HEIGHT);
        hControlSplitPane.setLeftComponent(vViewSplitPane);

        vViewSplitPane.setRightComponent(canvasBottom);
        vViewSplitPane.setResizeWeight(0.75);
        vViewSplitPane.setContinuousLayout(true);

        // viewPanel = new JPanel();
        canvasMain = createJOGLCanvas(Constants.CANVAS_MAIN_WIDTH, Constants.CANVAS_MAIN_HEIGHT);

        vViewSplitPane.setLeftComponent(canvasMain);

        panControls = new JPanel();
        panControls.setSize(new Dimension(120, 10));



        //JScrollPane scrollPane = new JScrollPane(); scrollPane.setMinimumSize(new Dimension(100, 23)); scrollPane.add(panControls);

        hControlSplitPane.setRightComponent(panControls);
        panControls.setLayout(new CardLayout(0, 0));

        JPanel panOptionsProto1 = new JPanel();
        panControls.add(panOptionsProto1, "name_optionsProto1");
        panOptionsProto1.setLayout(new BoxLayout(panOptionsProto1, BoxLayout.Y_AXIS));

        JComboBox lstProjects = new JComboBox();

        DefaultComboBoxModel projectsModel = new DefaultComboBoxModel();
        final SolutionInfos nullProject = new SolutionInfos(null, "-", null, null, null, null, null, null, null, null,
                null);
        projectsModel.addElement(nullProject);
        for (SolutionInfos sol : solInfosCol) {

            projectsModel.addElement(sol);


        }

        lstProjects.setModel(projectsModel);

        lstProjects.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                JComboBox cb = (JComboBox) e.getSource();
                SolutionInfos selectedItem = (SolutionInfos) cb.getSelectedItem();

                if (selectedItem == nullProject) {

                } else {

                    initProgressControls();

                    Timer.getInstance().start();
                    codeHistoryCtrl.load(selectedItem.getNom(), null, new Runnable() {

                        @Override
                        public void run() {

                            UserInteractions.getInstance().clearSelectionFilters();
                            UserInteractions.getInstance().setSelectedClusterFilter(null);

                            UserInteractions.getInstance().clearSelectedNodes();

                            IGraphLayoutHistory.getInstance().clearCachedLayoutComputations();

                            ClusterVisualShape.refreshAll();

                            visuBottom.repaint();
                            visuMain.repaint();


                        }
                    });



                }
            }

        });

        JPanel mainPanel = new JPanel();
        panOptionsProto1.add(mainPanel);
        mainPanel.setLayout(new MigLayout("", "[grow]", "[][][][][][][][][][][][][][][][][]"));

        JLabel lblData = new JLabel("Data");
        mainPanel.add(lblData, "cell 0 0");

        mainPanel.add(lstProjects, "cell 0 1,growx");

        if (UserInteractions.getInstance().isExperimentMode())
            lstProjects.setEnabled(false);




        JLabel lblInstanceSelector = new JLabel("Instance Selector");
        mainPanel.add(lblInstanceSelector, "cell 0 12");

        cboInstanceSelect = new JComboBox();

        cboInstanceSelect.setPreferredSize(new Dimension(Constants.CONTROL_PANEL_WIDTH, cboInstanceSelect.getHeight()));
        cboInstanceSelect.setMaximumSize(new Dimension(Constants.CONTROL_PANEL_WIDTH, 32767));
        // -

        instanceModel = new DefaultComboBoxModel();

        GraphImpl nullGraph = new GraphImpl(VilogToIGraphVisitor.getGraphMapper());
        INode nullGraphNode = new GraphNode(0, "all instances", nullGraph);
        nullGraphNode.setAttributeValue(nullGraph.getGraphMapper().getNodeNameAttribute(), nullGraphNode.getName());
        nullInstance = new ClusterImpl(nullGraph, 0, nullGraphNode);

        cboInstanceSelect.setModel(instanceModel);

        if (UserInteractions.getInstance().isExperimentMode())
            cboInstanceSelect.setEnabled(false);

        // show hovered element tooltip
        cboInstanceSelect.setRenderer(new ListCellRenderer() {

            @Override
            public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected,
                                                          boolean cellHasFocus) {
                JComponent component = (JComponent) new DefaultListRenderer().getListCellRendererComponent(list, value,
                        index, isSelected, cellHasFocus);

                component.setToolTipText(value.toString());

                return component;

            }
        });
        cboInstanceSelect.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                JComboBox cb = (JComboBox) e.getSource();
                ICluster selectedItem = (ICluster) cb.getSelectedItem();
                //System.out.println(selectedItem);

                if (selectedItem == null) {


                    //if we select all instances - remove all previous filters
                    //clearSelectedNodes();

                }
                else {

                    if (selectedItem ==nullInstance) {
                        // null
                        UserInteractions.getInstance().setSelectedClusterFilter(null);

                    } else {

                        // Load the specified cluster e.g., either hide all other clusters (and possibly their children)
                        UserInteractions.getInstance().setSelectedClusterFilter(selectedItem);


                    }

                    if (selectedItem == nullInstance) {

                        UserInteractions.getInstance().clearSelectedNodes();
                    }
                    else if (UserInteractions.getInstance().isShowClusterAlone()) {


                        //if show cluster/instances alone mode - apply a filter on the cluster + its nodes + the key element
                        UserInteractions.getInstance().clearSelectedNodes();
                        for (ICluster graphCluster : codeHistoryCtrl.getAllClusterRevisions(selectedItem)) {

                            for(INode nodeCluster : graphCluster.getNodes()){

                                UserInteractions.getInstance().addSelection(nodeCluster,false);
                            }
                            UserInteractions.getInstance().addSelection(graphCluster,false);

                        }
                        UserInteractions.getInstance().setShowFocusedItemsOnly(true);



                    } else {
                        //no filter applied - show all elements
                        UserInteractions.getInstance().clearSelectedNodes();

                    }

                    // UserInteractions.getInstance().updateSelectionFilters();
                }

                visuBottom.getLayout().invalidate();
                visuMain.getLayout().invalidate();
                visuBottom.repaint();
                visuMain.repaint();
            }

        });

        // -
        mainPanel.add(cboInstanceSelect, "cell 0 13,growx");

        AutoCompleteDecorator.decorate(cboInstanceSelect);

        /*
        AutoCompleteDecorator.decorate(cboInstanceSelect, new ObjectToStringConverter() {

            @Override
            public String getPreferredStringForItem(Object arg0) {
                ICluster clusterObj = (ICluster) arg0;

                // return the id (e.g., the user can type the id to select that instance)

                //the user can search by wildcard.
                String keymatch = "";

                if (clusterObj != null) {

                    if (clusterObj.getDefinedForNode() == null) {
                        keymatch = "";
                    } else {

                        if (clusterObj == nullInstance) {
                            keymatch = clusterObj.getDefinedForNode().getName();
                        } else {
                            String keyNodeName = (String) clusterObj.getDefinedForNode().getAttributeValue(clusterObj.getGraph().getGraphMapper().getNodeNameAttribute());

                            keymatch = new JavaParserNamespace(keyNodeName).getElementName().toLowerCase();
                        }
                    }

                }

                return keymatch;


            }

        });  */



        JLabel lblNameFilter = new JLabel("Name Filter:");
        mainPanel.add(lblNameFilter, "cell 0 15");
        final JTextField txtNameFilter = new JTextField("");

        mainPanel.add(txtNameFilter, "cell 0 16,growx");

        txtNameFilter.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {


                UserInteractions.getInstance().setClassnameFilter(txtNameFilter.getText());
                visuMain.getLayout().invalidate();
                visuMain.repaint();

            }
        });

        JLabel lblInfos = new JLabel("Infos");
        mainPanel.add(lblInfos, "cell 0 17");

        txtInfos = new JTextArea();
        txtInfos.setLineWrap(true);
        txtInfos.setColumns(14);
        txtInfos.setWrapStyleWord(true);
        txtInfos.setRows(16);

        txtInfosScrollPane = new JScrollPane(txtInfos);

        mainPanel.add(txtInfosScrollPane, "cell 0 18,growx");

        // Set main visu and bottom visu
        selectVisu(VisuFactory2.VISU_SOFTVIS_OVERVIEW, VisuFactory.VISU_TIMELINE);

        switchBottomDisplayMode(VisuTimelineLayout.INSTANCES_HISTORY_MODE);


    }

    private void switchBottomDisplayMode(String displayMode) {
        if (visuBottom != null) {
            if (visuBottom.getLayout() instanceof VisuTimelineLayout) {
                VisuTimelineLayout visuLayout = (VisuTimelineLayout) visuBottom.getLayout();
                visuLayout.switchDisplayMode(displayMode);
                visuBottom.repaint();
            }

        }
    }

    public MainAppWindowContext2 getContext() {


        return new MainAppWindowContext2() {


            @Override
            public GLDrawer getVisuMain() {
                return visuMain;
            }

            @Override
            public GLDrawer getVisuBottom() {
                return visuBottom;
            }

            @Override
            public CodeHistoryController getCodeHistoryController() {
                return codeHistoryCtrl;
            }

            @Override
            public SoftVisMainWindow getMainAppWindow() {
                return SoftVisMainWindow.this;
            }
        };
    }

    public void SetMenuItem(ICluster cluster){

        if(cluster != null)
            instanceModel.setSelectedItem(cluster);
    }

    public   void updateClusterComboBox() {

        instanceModel.removeAllElements();

        instanceModel.addElement(nullInstance);
        java.util.List<ICluster> lstAllClusters = codeHistoryCtrl.getAllClusters();
        java.util.List<String> lstClusterInstanceAdded = new ArrayList<String>();

        for (ICluster cluster : lstAllClusters) {

            //we can have several clusters for the same instance (because they exist at different times)
            //however, in the selectable list we only need one instance
            if (lstClusterInstanceAdded.contains(""+cluster.getId()) == false ) {

                if (JavaGraphUtil.visibleIHCluster(cluster)) {

                    instanceModel.addElement(cluster);

                    lstClusterInstanceAdded.add( ""+cluster.getId() );
                }
            }
        }
        //ajouter les clusters manquants a partir de la derniere r�vision

        RevisionTime LastRevision = codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions().last() ;
        IGraph softGraph = codeHistoryCtrl.getGraph(LastRevision);

        if(softGraph.getClusters().size()>lstClusterInstanceAdded.size()){

            for(ICluster cluster : softGraph.getClusters()){

                if (lstClusterInstanceAdded.contains(""+cluster.getId()) == false ){

                    if (JavaGraphUtil.visibleIHCluster(cluster)) {

                        instanceModel.addElement(cluster);

                        lstClusterInstanceAdded.add( ""+cluster.getId() );
                    }
                }
            }
        }

    }
    //-------------------------------------------------------------------------------------------------------



    private void resetControlsToDefault() {

    }

    private BasicGLComponent createJOGLCanvas(int w, int h) {
        GLCapabilities caps = new GLCapabilities(GLProfile.getDefault());
        caps.setDoubleBuffered(true);
        caps.setHardwareAccelerated(true);
        return new BasicGLComponent(caps, w, h);
    }

    private void selectVisu(String mainVisuName, String bottomVisuName) {

        initProgressControls();

        visuMain = createVisu(mainVisuName, this.codeHistoryCtrl);

        if (visuMain != null) {

            this.canvasMain.setGlDrawer(visuMain);
            final PopupMenuInteractor popup = new PopupMenuInteractor(visuMain, codeHistoryCtrl,getContext().getMainAppWindow());
            visuMain.addShapeEventListener(new ShapeEventListener()  {

                @Override
                public void shapeClicked(InputEvent e, VisualShape shape) {

                    if(SwingUtilities.isRightMouseButton((MouseEvent) e))
                    {

                        visuMain.addInteractor(popup);
                    }


                }

                @Override
                public void shapeHovered(InputEvent e, VisualShape shape) {

                    // Logger.getInstance().log(getClass(), "hovered shape " +
                    // shape, 0);

                    if (shape != null && shape.getData() != null) {

                        Object value = shape.getData();

                        String infos = "";
                        if (value instanceof ICluster) {

                            infos = "Cluster" + String.format("%n%n");
                            infos += "id: " + ((ICluster) value).getId() + String.format("%n");
                            infos += "name : " + ((ICluster) value).getDefinedForNode().getAttributeValue(Constants.ATTRIBUTE_NAMESPACE).toString() + String.format("%n");
                            infos += "";
                        }
                        else if (value instanceof INode) {

                            INode node = (INode) value;

                            String nodeType = (String) shape.getAttribute(Constants.ATTRIBUTE_NODE_TYPE);
                            String nodens = "";

                            if (node.getAttributeValue(Constants.ATTRIBUTE_NAMESPACE) != null) {
                                nodens =  node.getAttributeValue(Constants.ATTRIBUTE_NAMESPACE).toString();
                            }

                            infos = nodeType + "" + String.format("%n%n");

                            infos += "id: " + node.getId() + String.format("%n");
                            infos += "name : " + nodens + String.format("%n");
                            infos += "";
                        }

                        else {
                            //   infos=shape.toString();

                        }

                        // Load infos into text box
                        txtInfos.setText(infos);
                        txtInfos.setCaretPosition(0);

                    }


                }

                @Override
                public void shapeExited(InputEvent e, VisualShape shape) {

                }

                @Override
                public void shapeDragged(InputEvent e, VisualShape shape) {

                }

            });


            this.canvasMain.invalidate();
            this.canvasMain.display();
        }

        visuBottom = createVisu(bottomVisuName, this.codeHistoryCtrl);

        if (visuBottom != null) {

            this.canvasBottom.setGlDrawer(visuBottom);

            visuBottom.addShapeEventListener(new ShapeEventListener() {

                @Override
                public void shapeClicked(InputEvent e, VisualShape shape) {

                    // Logger.getInstance().log(getClass(), "clicked shape " + shape, 0);

                }

                @Override
                public void shapeHovered(InputEvent e, VisualShape shape) {

                    // Logger.getInstance().log(getClass(), "hovered shape " +
                    // shape, 0);

                    if (shape != null && shape.getData() != null) {

                        //if any object in another view (bottom one) is hovered - make sure no hovered object in the main view (can happen if zoomed a lot and moving from top to bottom objects directly)
                        SoftVisuOverviewController ctrl = (SoftVisuOverviewController) visuMain.getEventHandler();
                        if (ctrl.getHoveredItem() != null) {
                            ctrl.clearAllHoveredItem();
                        }

                        Object value = shape.getData();

                        String infos = "";


                        if (shape instanceof TimeSliceShape) {

                            String tooltip = (String) ((TimeSliceShape)shape).getRevisionInfos();

                            RevisionTimeSet rev = (RevisionTimeSet) value;

                            infos = "Revision " + String.format("%n");
                            infos += "first: " + rev.first() + String.format("%n");
                            if (rev.first().getRevision() != rev.last().getRevision()) {
                                infos += "last: " + rev.last() + String.format("%n");
                            }
                            infos += "infos: " + tooltip + String.format("%n");
                            infos += "";
                        }
                        else {


                            if (Constants.DEBUG_MODE) {

                                infos=shape.toString();

                                if (shape.getAttribute("changes") != null) {
                                    infos = shape.getAttribute("changes").toString();
                                }
                            }

                        }

                        // Load infos into text box
                        txtInfos.setText(infos);
                        txtInfos.setCaretPosition(0);

                    }


                }

                @Override
                public void shapeExited(InputEvent e, VisualShape shape) {

                }

                @Override
                public void shapeDragged(InputEvent e, VisualShape shape) {

                }

            });

            this.canvasBottom.invalidate();
            this.canvasBottom.display();
        }

        // notify the visu of some user selection / controller changes
        this.codeHistoryCtrl.addListener(this);
        // this.codeHistoryCtrl.addListener(visuBottom);


    }

    private GLDrawer createVisu(String mainVisuName, CodeHistoryController codeHistoryCtrl) {

        return VisuFactory2.createVisu(mainVisuName, codeHistoryCtrl);

    }

    private void initProgressControls() {

        if (progress != null) {
            progress.close();
            progress = null;
        }
        progress = new ProgressMonitor(frame, "Loading Data...", "", 0, 100);
        progress.setProgress(0);

        resetControlsToDefault();
        repaint(true, true);
    }

    private class MyDispatcher implements KeyEventDispatcher {
        @Override
        public boolean dispatchKeyEvent(KeyEvent e) {
            if (e.getID() == KeyEvent.KEY_PRESSED) {

                if (e.isControlDown() && e.getKeyCode() == KeyEvent.VK_S) {
                    loadSettingsDefaults();
                    JOptionPane.showMessageDialog(null, "Settings reloaded.");
                }

            } else if (e.getID() == KeyEvent.KEY_RELEASED) {

            } else if (e.getID() == KeyEvent.KEY_TYPED) {

            }
            // pass to the next dispatcher
            return false;
        }
    }

    @Override
    public void controllerUpdate(Object src, ControllerEvent event) {

        // repaint when control/user selection changed (e.g., new timeslice
        // range selected)
        repaint(true, false);
    }

    private void repaint(boolean invalidateMain, boolean invalidateBottom) {

        Logger.getInstance().log(getClass(), "repainting visus...", 3);

        if (invalidateMain) {
            if (visuMain != null && visuMain.getLayout() != null)
                visuMain.getLayout().invalidate();
        }
        if (invalidateBottom) {
            if (visuBottom != null && visuBottom.getLayout() != null)
                visuBottom.getLayout().invalidate();
        }

        if (visuMain != null)
            visuMain.repaint();
        if (visuBottom != null)
            visuBottom.repaint();


    }

    public void loadSettingsDefaults() {

        // Load defaults
        UserSettings settings = UserSettings.getInstance();

        // type of changes to show
        settings.setSetting("settingName", true);

        // categories
        settings.addCategoryOfSettings("catName", new String[]{
                "val1", "val2"});

        // force repaint when toggling mecanims to show for instance.
        settings.addUserSettingsListener(new UserSettingsListener() {

            @Override
            public void userSettingChanged(Object src, String settingName, Object settingOldValue,
                                           Object settingNewValue) {

                //   updateClusterComboBox();
                repaint(false, false);
            }

        });

        // force repaint when the user changes custom filters (setting a cluster
        // in focus) for example.
        UserInteractions.getInstance().addUserSettingsListener(new UserSettingsListener() {

            @Override
            public void userSettingChanged(Object src, String settingName, Object settingOldValue,
                                           Object settingNewValue) {

                // updateClusterComboBox();

                if (settingName == null)
                    repaint(true, true);
                    //else if (settingName.equals("instanceHistoryType"))
                    //    repaint(false,true);
                else
                    repaint(true,true);

            }
        });

    }
    public void AddInstance(ICluster instance){


        instanceModel.addElement(instance);

    }

    @Override
    public boolean taskProgress(String taskName, double taskProgressRatio) {

        //show progress using 10% chunks.
        double ratioChunk = 0.10;
        if (lastShownProgressRatio == null || (taskProgressRatio - lastShownProgressRatio) >= ratioChunk || taskProgressRatio <= 0.0 || taskProgressRatio >= 1.0) {

            Logger.getInstance().log(getClass(), "Task Progress - " + taskName + " - " + String.format("%.1f", new BigDecimal(taskProgressRatio * 100.0)) + "%",2);

            lastShownProgressRatio = taskProgressRatio;
        }
        if (isCancelled()) {
            return false;
        }

        if (taskName == null && taskProgressRatio >= 1) {
            progress.setProgress(1);
            progress.close();

            updateClusterComboBox();
            repaint(true, true);

        } else {
            int taskRatio = (int) (taskProgressRatio * 99);
            if (taskRatio >= 100) {
                taskRatio = 99;
            }
            progress.setProgress(taskRatio); // do not close progress window for intermediate steps
            progress.setNote(taskName);

        }

        return true;
    }

    @Override
    public boolean isCompleted() {
        return UserInteractions.getInstance().dataIsLoaded() == true;
    }

    @Override
    public boolean isCancelled() {
        return progress.isCanceled();
    }

}