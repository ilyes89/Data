package softvis.ui;


import graphics.GraphicsWrapper;
import infoHidingVisu.app.Constants;
import infoHidingVisu.change.CodeChangeElement;
import infoHidingVisu.codehistory.CodeHistoryController;
import infoHidingVisu.codehistory.FileHistoryInfo;
import infoHidingVisu.graphevolution.RevisionTime;
import infoHidingVisu.graphics.GraphicsWrapper2;
import infoHidingVisu.interactor.AbstractVisualShapeInteractor;
import infoHidingVisu.shape.ClusterVisualShape;
import infoHidingVisu.shape.VisualShapeAttributes;
import infoHidingVisu.ui.UserInteractions;
import infoHidingVisu.util.JavaGraphUtil;
import infoHidingVisu.util.JavaParserUnit;
import infoHidingVisu.util.JavaParserUtil;
import japa.parser.ast.CompilationUnit;
import vilog.common.data.*;
import visu.core.GLDrawer;
import visu.core.VisualShape;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;
import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Rectangle2D.Double;
import java.util.*;
import java.util.List;

public class PopupMenuInteractor extends AbstractVisualShapeInteractor implements PopupMenuListener {

    private JPopupMenu popupMenu;
    private ButtonGroup group  = new ButtonGroup();
    private List<JMenuItem> currentMenuItems = new ArrayList<JMenuItem>();
    private JMenuItem selectClusterMenu;
    private JMenu ListPointMenu;
    private JMenuItem hoveredItemMenu;
    private JMenuItem showCodeMenu;
    private GraphicsWrapper2 gw2;
    private CodeHistoryController codeHistoryCtrl;
    private ArrayList<INode> ListPoint = new ArrayList<INode>();
    private SoftVisMainWindow window;


    public PopupMenuInteractor(GLDrawer drawer,CodeHistoryController codeHistoryCtrl,SoftVisMainWindow window) {
        super(drawer);

        this.codeHistoryCtrl=codeHistoryCtrl;
        this.window=window;

        createPopupMenu(null);
    }


    private Double selRect;
    private JMenuItem showHideFocusedElementsMenu;


    @Override
    public void setRenderingContext(GraphicsWrapper gw) {
        // TODO Auto-generated method stub

    }


    @Override
    public void mouseMoved( MouseEvent e ) {

        if (popupMenu.isVisible()) {
            return;
        }
        super.mouseMoved(e);

    }

    @Override
    public void preRender(GraphicsWrapper gw) {
        // TODO Auto-generated method stub

    }

    @Override
    public void mousePressed(MouseEvent e) {


        if (popupMenu.isVisible() == false) {
            super.mousePressed(e);
        }

    }

    @Override
    public void mouseReleased(MouseEvent e) {

        super.mouseReleased(e);


        if (popupMenu.isVisible() == false) {

            if (SwingUtilities.isRightMouseButton(e)) {

                createPopupMenu(getHoveredItem());
                popupMenu.show(e.getComponent(), e.getX(), e.getY());
            }
        }


    }

    @Override
    public void mouseDragged(MouseEvent e) {

        super.mouseDragged(e);


    }

    @Override
    public void render(GraphicsWrapper gw) {

        GraphicsWrapper2 gw2 = (GraphicsWrapper2) gw;

        this.gw2=gw2;
        if (latestMouseEvent != null && latestMouseEvent.isControlDown()) {

            if (draggingMouse && draggingShape == false) {

                graphics.Point2D pt = gw2.convertSystemPoint2(this.startOfDragX, this.startOfDragY);
                pt = gw.convertPixelsToWorldSpaceUnits(new graphics.Point2D(startOfDragX, startOfDragY));

                graphics.Point2D ptEnd = gw2.convertSystemPoint2(mouse_x, mouse_y);
                ptEnd = gw.convertPixelsToWorldSpaceUnits(new graphics.Point2D(mouse_x, mouse_y));



            }

        }


    }

    @Override
    public VisualShape getShape() {
        //the interactor has no shape by itself
        return null;
    }

    public void MoveElements(INode hoveredNode,ArrayList<INode> List){

        double offset = 50;
        graphics.Point2D ptNeighbors = gw2.convertSystemPoint2(mouse_x+offset, mouse_y+offset);
        ptNeighbors = gw2.convertPixelsToWorldSpaceUnits(new graphics.Point2D(mouse_x+offset, mouse_y+offset));
        graphics.Point2D ptNeighborsFinal = ptNeighbors;

        if(List.size()>0){
            double offsetx = 50 ;
            double offsety = 100 ;
            for(INode nodeIn : List){

                VisualShape vsNodeIn = (VisualShape) nodeIn.getAttributeValue(VisualShapeAttributes.VISUAL_SHAPE);

                if (nodeIn != hoveredNode && vsNodeIn != null) {
                    vsNodeIn.moveTo(ptNeighborsFinal.x()+offsetx, ptNeighborsFinal.y()+offsety);
                }
                offsetx += 100 ;
                offsety += 50 ;
            }
        }
    }

    //return the list of all children of the new stability point
    public ArrayList<INode> getChildrenList (INode hoveredNode){

        ArrayList<INode> childrenList = new ArrayList<INode>();
        int count = 0;
        INode tagNode ;

        for(IEdge edge : hoveredNode.getIncomingEdges()){

            if(edge.includesEdgeType(JavaParserUtil.EDGE_TYPE_EXTENDS_DEP)){
                childrenList.add(edge.getInNode());

            }
        }

        while(count<childrenList.size())
        {
            tagNode = childrenList.get(count);
            for(IEdge edge : tagNode.getIncomingEdges())
            {
                if(edge.includesEdgeType(JavaParserUtil.EDGE_TYPE_EXTENDS_DEP)){
                    childrenList.add(edge.getInNode());
                }
            }
            count ++;
        }

        return childrenList;
    }


    protected void createPopupMenu(VisualShape hoveredShape) {

        if (true || popupMenu == null) {

            popupMenu = new JPopupMenu();
            hoveredItemMenu = new JMenuItem("");
            hoveredItemMenu.setEnabled(false);
            popupMenu.add( hoveredItemMenu );
            popupMenu.addSeparator();





            JMenuItem clearSelectionMenu = new JMenuItem("Clear Selection");
            clearSelectionMenu.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent e) {
                    UserInteractions.getInstance().clearSelectedNodes();

                    ClusterVisualShape.refreshAll();
                    glDrawer.repaint();
                }

            });

            popupMenu.add( clearSelectionMenu );
            popupMenu.addSeparator();

            //if (showHideFocusedElementsMenu == null) {
            showHideFocusedElementsMenu = new JMenuItem("Show/Hide Elements in Focus");
            //}
            updatePopupFocusText();

            showHideFocusedElementsMenu.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent e) {

                    //toggle show focus items only
                    UserInteractions.getInstance().toggleShowFocusedItemsOnly();
                    updatePopupFocusText();

                    ClusterVisualShape.refreshAll();
                    glDrawer.repaint();
                }

            });


            if (UserInteractions.getInstance().getSelectedNodes().isEmpty()) {
                showHideFocusedElementsMenu.setEnabled(false);
                clearSelectionMenu.setEnabled(false);

            }
            else {
                showHideFocusedElementsMenu.setEnabled(true);
                clearSelectionMenu.setEnabled(true);
            }

            popupMenu.add( showHideFocusedElementsMenu );

            //popupMenu.addSeparator();
            //popupMenu.add( new JComboBox(new String[] {"first", "second", "thrid", "fourth"}) );


            popupMenu.addPopupMenuListener(this);
        }

        //dynamically build parts of the menu
        hoveredItemMenu.setText( "(hovered item)" );

        //selectClusterMenu.removeAll();
        //selectClusterMenu.setVisible(false);
        //selectClusterMenu.setEnabled(false);

        //showCodeMenu.setEnabled(false);
        //showCodeMenu.setVisible(false);

        //clear group
        Enumeration<AbstractButton> enumGroupElements = group.getElements();
        List<AbstractButton> itemsToRemove = new ArrayList<AbstractButton>();
        while (enumGroupElements.hasMoreElements()) {
            AbstractButton toRemove = enumGroupElements.nextElement();
            itemsToRemove.add(toRemove);
        }
        for (AbstractButton itemToRemove : itemsToRemove) {
            group.remove(itemToRemove);
        }
        currentMenuItems.clear();
        popupMenu.addSeparator();
        ListPointMenu = new JMenu("List of Stability Point");
        for(INode node : ListPoint){
            final JMenuItem item = new JMenuItem(node.getAttributeValue("name").toString());
            item.addMouseListener(new MouseListener() {

                @Override
                public void mouseReleased(MouseEvent e) {
                    // TODO Auto-generated method stub
                    //System.out.println("right clic");

                }

                @Override
                public void mousePressed(MouseEvent e) {
                    // TODO Auto-generated method stub
                    if(SwingUtilities.isRightMouseButton((MouseEvent) e))
                    {
                        JOptionPane option = new JOptionPane();
                        INode SelectedNode = null ;
                        int op = option.showConfirmDialog(null, "You will remove this Stability Point !", "information", JOptionPane.YES_NO_OPTION);
                        if(op == JOptionPane.OK_OPTION )
                        {

                            for(INode node : ListPoint){

                                if(node.getAttributeValue("name").equals(item.getText()))
                                {
                                    ListPoint.remove(node);
                                    SelectedNode = node ;
                                    break;
                                }
                            }

                            if(SelectedNode != null){
                                IGraph igraphAtRev;
                                for (RevisionTime t : codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions()) {

                                    igraphAtRev = codeHistoryCtrl.getGraph(t);

                                    for(ICluster cluster : igraphAtRev.getClusters())
                                    {
                                        if(cluster.getDefinedForNode().equals(SelectedNode))
                                        {
                                            igraphAtRev.removeCluster(cluster);
                                        }
                                    }

                                }
                                window.updateClusterComboBox() ;
                            }
                        }

                    }

                }

                @Override
                public void mouseExited(MouseEvent e) {
                    // TODO Auto-generated method stub

                }

                @Override
                public void mouseEntered(MouseEvent e) {
                    // TODO Auto-generated method stub

                }

                @Override
                public void mouseClicked(MouseEvent e) {


                }
            });
            ListPointMenu.add(item);
        }
        popupMenu.add(ListPointMenu);
        popupMenu.addSeparator();

        if (hoveredShape != null) {


            //Get hovered cluster... ... and get all the cluster overlapping with this cluster
            if (hoveredShape.getData() != null && hoveredShape.getData() instanceof ICluster) {

                ICluster hoveredCluster = (ICluster) hoveredShape.getData();
                Set<ICluster> overlappingClusters = hoveredCluster.getOverlappingClusters();

                //save for each "set of clusters" which cluster is "selected"

                //String selKeyNode = hoveredShape.getAttribute(Constants.CLUSTER_SELECTED_MAINKEYNODE);
                //if (selKeyNode != null) {

                if (hoveredCluster != null) {


                    //currentMenuItems.add( new JRadioButtonMenuItem( hoveredCluster.getId() + " - " + hoveredCluster.getDefinedForNode().getAttributeValue(Constants.ATTRIBUTE_NAMESPACE)) );
                    hoveredItemMenu.setText( hoveredCluster.getId() + " - " + hoveredCluster.getDefinedForNode().getAttributeValue(Constants.ATTRIBUTE_NAMESPACE) );



                }

                //check if overlapping clusters are of the same type
                String ihCluster = JavaGraphUtil.getClusterIHType(hoveredCluster);

                //create entries for all key elements
                for (ICluster overlappingCluster : overlappingClusters) {

                    //for clusters defined at method-level (e.g., instability tag) do not include these
                    if (JavaGraphUtil.getClusterIHDetailLevel(overlappingCluster) != JavaGraphUtil.METHOD_CLUSTER_LEVEL) {
                        String overlappingIhCluster = JavaGraphUtil.getClusterIHType(overlappingCluster);

                        if (ihCluster == overlappingIhCluster) {

                            JMenuItem clusterMenuItem = new JRadioButtonMenuItem( overlappingCluster.getId() + " - " + overlappingCluster.getDefinedForNode().getAttributeValue(Constants.ATTRIBUTE_NAMESPACE));

                            currentMenuItems.add( clusterMenuItem );

                            //On hovering a cluster item, highlights it
                            clusterMenuItem.addChangeListener(createRolloverAction(overlappingCluster));

                            clusterMenuItem.addActionListener( createClickAction(overlappingCluster) );
                        }
                    }


                }


                selectClusterMenu = new JMenu("Select Cluster");
                //select the proper one
                for (JMenuItem oldMenuItem : currentMenuItems) {
                    selectClusterMenu.add(oldMenuItem);
                    group.add(oldMenuItem);
                    group.setSelected(oldMenuItem.getModel(), false);
                }

                popupMenu.addSeparator();
                popupMenu.add( selectClusterMenu );

                //}


            }
            else if (hoveredShape.getData() != null && hoveredShape.getData() instanceof INode) {

                final INode hoveredNode = (INode) hoveredShape.getData();
                String nodeType = JavaParserUtil.getNodeTypeGeneric(hoveredNode);

                double offset = 50;
                graphics.Point2D ptNeighbors = gw2.convertSystemPoint2(mouse_x+offset, mouse_y+offset);
                ptNeighbors = gw2.convertPixelsToWorldSpaceUnits(new graphics.Point2D(mouse_x+offset, mouse_y+offset));
                final graphics.Point2D ptNeighborsFinal = ptNeighbors;
                //-------------------------------------------------------
                JMenuItem AddPoint = new JMenuItem("Add Stability Point");
                AddPoint.setEnabled(false);
                if (nodeType.equals("NODE_TYPE_CLASS") || nodeType.equals("NODE_TYPE_ABSTRACT_CLASS"))
                {

                    AddPoint.setEnabled(true);
                    ArrayList<INode> ListChildren = getChildrenList(hoveredNode);
                    MoveElements(hoveredNode,ListChildren);

                    AddPoint.addActionListener(new ActionListener() {

                        @Override
                        public void actionPerformed(ActionEvent e) {
                            // TODO Auto-generated method stub

                            int IdRev = 0 ;
                            List<INode> ChildrenList ;


                            loop:
                            for(RevisionTime rev : codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions()){

                                IGraph graph = codeHistoryCtrl.getGraph(rev);
                                for(INode node : graph.getNodes())
                                {
                                    if(node.equals(hoveredNode) && node.getAttributeValue("nodeType").equals("NODE_TYPE_INTERFACE"))
                                    {
                                        IdRev = rev.getRevision().intValue() ;
                                        break loop;
                                    }
                                }

                            }
                            lp:
                            if(IdRev != 0){

                                for(RevisionTime revision : codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions()){

                                    if(revision.getRevision().intValue() != IdRev)
                                    {
                                        IGraph igraphAtRev = codeHistoryCtrl.getGraph(revision);
                                        INode definedForNodeInGraph = igraphAtRev.getNode(hoveredNode.getId());

                                        if (definedForNodeInGraph != null) {

                                            GraphNodeCollection nodesInClusterInGraph = new NodeCollection(igraphAtRev.getGraphMapper());
                                            ChildrenList = getChildrenList(definedForNodeInGraph);
                                            for(INode node : ChildrenList){

                                                nodesInClusterInGraph.add(node);
                                            }

                                            igraphAtRev.addCluster(definedForNodeInGraph, nodesInClusterInGraph, new HashMap<String, Object>());
                                        }

                                    }else{

                                        RevisionTime LastRevision = codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions().last() ;
                                        IGraph softGraph = codeHistoryCtrl.getGraph(LastRevision);
                                        List<ICluster> NewCluster = softGraph.getClustersDefinedForNode(hoveredNode);
                                        window.SetMenuItem(NewCluster.get(NewCluster.size()-1));

                                        break lp;
                                    }
                                }

                            }
                            else{

                                if(! ListPoint.contains(hoveredNode))
                                {
                                    ListPoint.add(hoveredNode);


                                    for (RevisionTime t : codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions()) {

                                        IGraph igraphAtRev = codeHistoryCtrl.getGraph(t);
                                        INode definedForNodeInGraph = igraphAtRev.getNode(hoveredNode.getId());

                                        if (definedForNodeInGraph != null) {

                                            GraphNodeCollection nodesInClusterInGraph = new NodeCollection(igraphAtRev.getGraphMapper());
                                            ChildrenList = getChildrenList(definedForNodeInGraph);
                                            for(INode node : ChildrenList){

                                                nodesInClusterInGraph.add(node);
                                            }

                                            igraphAtRev.addCluster(definedForNodeInGraph, nodesInClusterInGraph, new HashMap<String, Object>());

                                        }
                                    }

                                    RevisionTime LastRevision = codeHistoryCtrl.getCodeHistory().getTimeslices().getAllRevisions().last() ;
                                    IGraph softGraph = codeHistoryCtrl.getGraph(LastRevision);
                                    List<ICluster> NewCluster = softGraph.getClustersDefinedForNode(hoveredNode);
                                    window.AddInstance(NewCluster.get(NewCluster.size()-1));
                                    window.SetMenuItem(NewCluster.get(NewCluster.size()-1));
                                }
                                else{
                                    System.out.println("this stability point exist");
                                }
                            }


                        }


                    });
                    popupMenu.add( AddPoint );
                    popupMenu.addSeparator();



                }


                //---------------------------------------------------------

                hoveredItemMenu.setText( hoveredNode.getId() + " - " + hoveredNode.getAttributeValue(Constants.ATTRIBUTE_NAMESPACE) );

                JMenuItem neighborsCloser = new JMenuItem("Bring Neighbors Closer");
                neighborsCloser.setVisible(true);


                neighborsCloser.addActionListener(new ActionListener() {

                    @Override
                    public void actionPerformed(ActionEvent e) {
                        double offset = 50 ;

                        //Get shapes of all related nodes (e.g., nodes coupled to this one)
                        for (IEdge neighborEdge : hoveredNode.getEdges() ) {
                            INode nodeIn = neighborEdge.getInNode();
                            INode nodeOut = neighborEdge.getOutNode();



                            VisualShape vsNodeIn = (VisualShape) nodeIn.getAttributeValue(VisualShapeAttributes.VISUAL_SHAPE);
                            VisualShape vsNodeOut = (VisualShape) nodeOut.getAttributeValue(VisualShapeAttributes.VISUAL_SHAPE);

                            if (nodeIn != hoveredNode && vsNodeIn != null) {
                                vsNodeIn.moveTo(ptNeighborsFinal.x()+offset, ptNeighborsFinal.y()+offset);

                            }

                            if (nodeOut != hoveredNode && vsNodeOut != null) {
                                vsNodeOut.moveTo(ptNeighborsFinal.x()+offset, ptNeighborsFinal.y()+offset);
                            }
                            offset+=50;



                        }


                    }

                });

                //popupMenu.addSeparator();
                popupMenu.add(neighborsCloser);

                if (hoveredNode.getEdges().isEmpty()) {
                    neighborsCloser.setEnabled(false);
                }
                else {
                    neighborsCloser.setEnabled(true);
                }


                showCodeMenu = new JMenuItem("Copy Code");
                showCodeMenu.setVisible(false);
                showCodeMenu.addActionListener(new ActionListener() {

                    @Override
                    public void actionPerformed(ActionEvent e) {

                        JavaParserUnit jpu = (JavaParserUnit) hoveredNode.getAttributeValue(Constants.ATTRIBUTE_JAVAPARSER_UNIT);
                        Object nodeImpl = hoveredNode.getAttributeValue(Constants.ATTRIBUTE_IMPL);
                        CompilationUnit cu = (CompilationUnit) hoveredNode.getAttributeValue(Constants.ATTRIBUTE_COMPILATION_UNIT);
                        String filename = (String) hoveredNode.getAttributeValue(Constants.ATTRIBUTE_FILENAME);
                        CodeChangeElement codeChange = (CodeChangeElement) hoveredNode.getAttributeValue(Constants.ATTRIBUTE_CODECHANGE);

                        String nodeNs = (String) hoveredNode.getAttributeValue(hoveredNode.getGraph().getGraphMapper().getNodeNameAttribute());

                        if (nodeNs != null) {
                            String nodeNsDotsSVNFormat = nodeNs.substring(0, nodeNs.length()-1).replace(":", ".");

                            FileHistoryInfo fileContentsAtRev = codeHistoryCtrl.getFileContentsAtRev(nodeNsDotsSVNFormat, hoveredNode.getTimestep());

                            String newline = System.getProperty("line.separator");
                            String copyCode = ">>>> Source code of " + nodeNs + " :rev" + hoveredNode.getTimestep() + "\r\n" + fileContentsAtRev.toString()+ "\r\n<<<<End\r\n";
                            //cross-platform new lines
                            copyCode = copyCode.replace("\r\n", newline);

                            Toolkit toolkit = Toolkit.getDefaultToolkit();
                            Clipboard clipboard = toolkit.getSystemClipboard();
                            StringSelection strSel = new StringSelection(copyCode);
                            clipboard.setContents(strSel, null);
                        }


                    }

                });

                // popupMenu.addSeparator();
                popupMenu.add(showCodeMenu);




            }

        }

    }


    private ActionListener createClickAction(ICluster overlappingCluster) {



        final ICluster fcluster = overlappingCluster;
        return new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {


                for (ICluster graphCluster : codeHistoryCtrl.getAllClusterRevisions(fcluster)) {
                    UserInteractions.getInstance().addSelection( graphCluster , false);
                }

                UserInteractions.getInstance().clearSelectionFilters();
                glDrawer.repaint();
            }


        };
    }


    private ChangeListener createRolloverAction(ICluster overlappingCluster) {
        final ICluster fcluster = overlappingCluster;
        return new ChangeListener() {

            @Override
            public void stateChanged(ChangeEvent e) {
                if (e.getSource() instanceof JMenuItem) {
                    JMenuItem item = (JMenuItem) e.getSource();
                    if (item.isSelected() || item.isArmed()) {

                        String clusterNs = (String) fcluster.getAttributeValue(Constants.ATTRIBUTE_NAMESPACE);
                        VisualShape clusterVs = glDrawer.getLayout().layoutShapes().findShape(clusterNs);
                        VisualShape clusterVs2 = (VisualShape) fcluster.getAttributeValue(VisualShapeAttributes.VISUAL_SHAPE);
                        System.out.println("Highlighted: " + item.getActionCommand() + " - cluster=" + fcluster + " vs=" + clusterVs + " vs2=" + clusterVs2);

                        glDrawer.repaint();
                    }
                }
            }
        };

    }


    @Override
    public void popupMenuWillBecomeVisible(PopupMenuEvent e) {

    }

    @Override
    public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {
        this.clearAllHoveredItem();
    }

    @Override
    public void popupMenuCanceled(PopupMenuEvent e) {
        this.clearAllHoveredItem();

    }


    private void updatePopupFocusText() {

        if (UserInteractions.getInstance().isOnlyShowFocusedItems() == false) {
            showHideFocusedElementsMenu.setText("Only Show Elements In Focus");
        }
        else {
            showHideFocusedElementsMenu.setText("Show All Elements");
        }
    }


}