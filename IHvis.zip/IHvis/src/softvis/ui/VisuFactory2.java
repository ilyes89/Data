package softvis.ui;

import infoHidingVisu.codehistory.CodeHistoryController;
import softvis.views.SoftVisuOverviewDrawer;
import softvis.views.VisuTimelineDrawer2;
import visu.core.GLDrawer;

/**
 * Created by seb on 2014-04-29.
 */
public class VisuFactory2 {
    public static final String VISU_TIMELINE = "Timeline";
    public static final String VISU_SOFTVIS_OVERVIEW = "SOFTVIS";

    public static GLDrawer createVisu(String visuName, CodeHistoryController codeHistoryCtrl) {

        if (visuName.equals(VisuFactory2.VISU_TIMELINE)) {
            return new VisuTimelineDrawer2(codeHistoryCtrl);
        }
        else if (visuName.equals(VisuFactory2.VISU_SOFTVIS_OVERVIEW)) {
            return new SoftVisuOverviewDrawer(codeHistoryCtrl);
        }

        else {
            throw new RuntimeException("Unsupported visu '" + visuName + "'");
        }

    }
}
