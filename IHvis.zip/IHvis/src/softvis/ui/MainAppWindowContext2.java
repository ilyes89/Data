package softvis.ui;

import infoHidingVisu.codehistory.CodeHistoryController;
import visu.core.GLDrawer;

/**
 * Created by seb on 2013-12-08.
 */
public interface MainAppWindowContext2 {


    public GLDrawer getVisuMain();

    public GLDrawer getVisuBottom();

    public CodeHistoryController getCodeHistoryController();

    public SoftVisMainWindow getMainAppWindow();
}
