package softvis.app;

import infoHidingVisu.ui.UserInteractions;
import softvis.ui.SoftVisMainWindow;
import vilog.common.utils.Logger;

/**
 * Created by seb on 2013-12-08.
 */
public class VariabilityAppStarter {


    public static void main(String[] args) {


        if (UserInteractions.getInstance().isLogging()) {

            Logger.getInstance().setSilence(false);
            Logger.getInstance().setLogLevel(3);
            Logger.getInstance().startFileOutput("./data/log.txt");

        }
        else {
            System.out.println("*** Logging turned off ***");
            Logger.getInstance().setSilence(true);
            Logger.getInstance().setLogLevel(-1);
            Logger.getInstance().setDebug(false);

        }

        VariabilityAppStarter app = new VariabilityAppStarter();
        app.start();

    }

    private void start() {

        // open the main app UI
        SoftVisMainWindow.main(new String[]{});
    }


}
